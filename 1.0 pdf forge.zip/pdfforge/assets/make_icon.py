"""Generates assets/icon.ico and assets/icon.png (pink-red page on black). Run: python assets/make_icon.py"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parent
S = 1024
im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
d = ImageDraw.Draw(im)
d.rounded_rectangle([20, 20, S - 20, S - 20], radius=230, fill=(0, 0, 0, 255), outline=(255, 45, 85, 255), width=22)
page = [(300, 190), (600, 190), (740, 330), (740, 840), (300, 840)]
d.polygon(page, fill=(255, 45, 85, 255))
d.polygon([(600, 190), (600, 330), (740, 330)], fill=(255, 179, 193, 255))
for path in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "C:/Windows/Fonts/segoeuib.ttf"):
    try:
        f = ImageFont.truetype(path, 190)
        break
    except OSError:
        f = ImageFont.load_default()
d.text((520, 600), "PDF", font=f, fill="white", anchor="mm")
im.save(OUT / "icon.png")
im.save(OUT / "icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("icons written")
