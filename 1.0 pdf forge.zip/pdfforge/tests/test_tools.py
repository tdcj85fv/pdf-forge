import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pypdfium2 as pdfium
from PIL import Image
from pypdf import PdfReader, PdfWriter
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

import core
from core import TOOLS, ToolError, execute, search


def run(tid, inputs, out, **opts):
    return execute(TOOLS[tid], inputs, opts, out)


@pytest.fixture(scope="session")
def files(tmp_path_factory):
    d = tmp_path_factory.mktemp("in")
    # photo-like image
    import random
    random.seed(1)
    img = Image.effect_noise((1800, 1200), 60).convert("RGB")
    img.save(d / "photo.jpg", quality=95)
    img.save(d / "photo.png")
    Image.new("RGBA", (200, 100), (255, 0, 0, 120)).save(d / "alpha.png")

    def make(name, pages, long=False):
        c = canvas.Canvas(str(d / name), pagesize=A4)
        for i in range(pages):
            c.setFont("Helvetica-Bold", 24)
            c.drawString(72, 780, f"Chapter {i + 1} Heading")
            c.setFont("Helvetica", 11)
            y = 740
            for j in range(12):
                c.drawString(72, y, f"Page {i + 1} line {j}: contact alice@example.com or call +91 98765 43210 about the budget.")
                y -= 16
            c.drawString(72, y - 10, "- bullet item one")
            c.drawString(72, y - 26, "- bullet item two")
            # ruled table
            x0, y0 = 72, 400
            for r in range(4):
                for cc in range(3):
                    c.rect(x0 + cc * 100, y0 - r * 24, 100, 24)
                    c.drawString(x0 + cc * 100 + 4, y0 - r * 24 + 8, f"R{r}C{cc}")
            c.drawImage(str(d / "photo.jpg"), 72, 100, 300, 200)
            c.showPage()
        c.save()
    make("a.pdf", 4)
    make("b.pdf", 2)
    # b2: slightly different text for compare
    c = canvas.Canvas(str(d / "b2.pdf"), pagesize=A4)
    c.drawString(72, 700, "Completely different content here.")
    c.showPage(); c.save()
    return d


def pages(p):
    return len(PdfReader(str(p)).pages)


def test_registry_and_search():
    assert len(TOOLS) >= 30
    assert TOOLS["merge"] in search("join")
    assert search("compress")[0].id == "compress"
    assert search("pdf word")[0].id in ("pdf_to_word", "word_to_pdf")
    assert search("zzzzqq") == []


def test_merge_split_remove_extract_organize(files, tmp_path):
    out = run("merge", [files / "a.pdf", files / "b.pdf"], tmp_path)[0]
    assert pages(out) == 6
    parts = run("split", [out], tmp_path, mode="Custom ranges", value="1-2, 5-last")
    assert [pages(p) for p in parts] == [2, 2]
    assert len(run("split", [out], tmp_path, mode="Each page")) == 6
    assert len(run("split", [out], tmp_path, mode="Every N pages", value="4")) == 2
    assert pages(run("remove_pages", [out], tmp_path, pages="1, 3-4")[0]) == 3
    assert pages(run("extract_pages", [out], tmp_path, pages="2-3")[0]) == 2
    assert len(run("extract_pages", [out], tmp_path, pages="2-3", separate=True)) == 2
    org = run("organize", [files / "a.pdf"], tmp_path, order="reverse")[0]
    assert "Chapter 4" in PdfReader(str(org)).pages[0].extract_text()
    with pytest.raises(ToolError):
        run("remove_pages", [files / "a.pdf"], tmp_path, pages="9")
    with pytest.raises(ToolError):
        run("merge", [files / "a.pdf"], tmp_path)


def test_compress_repair(files, tmp_path):
    big = run("jpg_to_pdf", [files / "photo.png"], tmp_path, name="big")[0]
    small = run("compress", [big], tmp_path, level="Extreme")[0]
    assert small.stat().st_size < big.stat().st_size
    bad = tmp_path / "bad.pdf"
    data = (files / "a.pdf").read_bytes()
    bad.write_bytes(data[:-300])  # truncated: xref lost
    fixed = run("repair", [bad], tmp_path)[0]
    assert pages(fixed) >= 1


def test_jpg_to_pdf(files, tmp_path):
    out = run("jpg_to_pdf", [files / "photo.jpg", files / "alpha.png"], tmp_path, size="A4", margin="Small")[0]
    assert pages(out) == 2
    w, h = PdfReader(str(out)).pages[0].mediabox.width, PdfReader(str(out)).pages[0].mediabox.height
    assert abs(float(w) - 595) < 2 or abs(float(w) - 842) < 2
    sep = run("jpg_to_pdf", [files / "photo.jpg", files / "alpha.png"], tmp_path, merge=False)
    assert len(sep) == 2


def test_pdf_to_jpg(files, tmp_path):
    imgs = run("pdf_to_jpg", [files / "b.pdf"], tmp_path)
    assert len(imgs) == 2 and Image.open(imgs[0]).size[0] > 500
    emb = run("pdf_to_jpg", [files / "b.pdf"], tmp_path, mode="Embedded images only", fmt="PNG")
    assert len(emb) >= 1


def test_word_excel_ppt_md(files, tmp_path):
    from docx import Document
    from openpyxl import load_workbook
    from pptx import Presentation
    docx = run("pdf_to_word", [files / "b.pdf"], tmp_path)[0]
    d = Document(str(docx))
    text = "\n".join(p.text for p in d.paragraphs)
    assert "Chapter 1" in text and len(d.tables) >= 1
    assert any(p.style.name.startswith("Heading") for p in d.paragraphs)
    xlsx = run("pdf_to_excel", [files / "b.pdf"], tmp_path)[0]
    ws = load_workbook(xlsx).worksheets[0]
    assert ws["A1"].value == "R0C0"
    for mode in ("Editable text", "Page pictures"):
        pptx = run("pdf_to_ppt", [files / "b.pdf"], tmp_path, mode=mode)[0]
        assert len(Presentation(str(pptx)).slides) == 2
    md = run("pdf_to_markdown", [files / "b.pdf"], tmp_path)[0].read_text(encoding="utf-8")
    assert "# " in md and "| R0C0 |" in md and "- bullet item one" in md


def test_office_to_pdf(files, tmp_path):
    from core.util import find_soffice
    if not find_soffice():
        pytest.skip("LibreOffice not installed")
    from docx import Document
    d = Document()
    d.add_paragraph("Hello from Word")
    d.save(tmp_path / "x.docx")
    out = run("word_to_pdf", [tmp_path / "x.docx"], tmp_path / "o")[0]
    assert "Hello from Word" in PdfReader(str(out)).pages[0].extract_text()


def _render_dark_bbox(pdf, i=0):
    pil = pdfium.PdfDocument(str(pdf))[i].render(scale=1).to_pil().convert("L")
    return pil, pil.point(lambda v: 255 if v < 140 else 0).getbbox()


def test_rotate_numbers_watermark_crop(files, tmp_path):
    rot = run("rotate", [files / "b.pdf"], tmp_path, pages="1")[0]
    assert PdfReader(str(rot)).pages[0].rotation == 90
    assert PdfReader(str(rot)).pages[1].rotation == 0
    num = run("page_numbers", [files / "a.pdf"], tmp_path)[0]
    assert "Page 4 of 4" in PdfReader(str(num)).pages[3].extract_text()
    # number on a rotated page must still land bottom-centre as seen by a reader
    blank = tmp_path / "blank.pdf"
    w = PdfWriter(); w.add_blank_page(595, 842); w.pages[0].rotate(90)
    w.write(blank)
    n2 = run("page_numbers", [blank], tmp_path, color="#000000", size=20)[0]
    pil, bb = _render_dark_bbox(n2)
    assert pil.size == (842, 595)
    assert bb[1] > 595 * 0.8 and abs((bb[0] + bb[2]) / 2 - 421) < 25, bb
    wm = run("watermark", [files / "b.pdf"], tmp_path, text="DRAFT")[0]
    assert "DRAFT" in PdfReader(str(wm)).pages[0].extract_text()
    wm2 = run("watermark", [files / "b.pdf"], tmp_path, text="", image=str(files / "alpha.png"), layout="Tiled")[0]
    assert pages(wm2) == 2
    cr = run("crop", [files / "b.pdf"], tmp_path, top=20, bottom=20, left=20, right=20)[0]
    pil = pdfium.PdfDocument(str(cr))[0].render(scale=1).to_pil()
    assert abs(pil.size[0] - (595 - 113)) < 4
    cr2 = run("crop", [rot], tmp_path, top=0, bottom=0, left=30, right=0, pages="1")[0]
    pil = pdfium.PdfDocument(str(cr2))[0].render(scale=1).to_pil()
    assert abs(pil.size[0] - 842) < 3 and abs(pil.size[1] - (595 - 85)) < 4 or abs(pil.size[0] - (842 - 85)) < 4


def test_edit_sign(files, tmp_path):
    out = run("edit_pdf", [files / "b.pdf"], tmp_path, text="Hello Edited", pages="1")[0]
    assert "Hello Edited" in PdfReader(str(out)).pages[0].extract_text()
    s = run("sign", [files / "b.pdf"], tmp_path, text="Omkar Borkar")[0]
    assert "Omkar Borkar" in PdfReader(str(s)).pages[1].extract_text()
    s2 = run("sign", [files / "b.pdf"], tmp_path, image=str(files / "alpha.png"), page="all")[0]
    assert pages(s2) == 2


def test_forms(tmp_path):
    from reportlab.pdfgen import canvas as cv
    f = tmp_path / "form.pdf"
    c = cv.Canvas(str(f))
    c.acroForm.textfield(name="fullname", x=100, y=700, width=200, height=24)
    c.showPage()
    c.save()
    out = run("pdf_forms", [f], tmp_path, values="fullname=Alice")[0]
    assert PdfReader(str(out)).get_fields()["fullname"].get("/V") == "Alice"
    flat = run("pdf_forms", [f], tmp_path, values="fullname=Bob", flatten=True)[0]
    assert not (PdfReader(str(flat)).get_fields() or {})
    with pytest.raises(ToolError):
        run("pdf_forms", [f], tmp_path, values="nope=1")


def test_security(files, tmp_path):
    prot = run("protect", [files / "b.pdf"], tmp_path, password="secret", allow_copy=False)[0]
    assert PdfReader(str(prot)).is_encrypted
    with pytest.raises(ToolError):
        run("merge", [prot, files / "a.pdf"], tmp_path)
    with pytest.raises(ToolError):
        run("unlock", [prot], tmp_path, password="wrong")
    un = run("unlock", [prot], tmp_path, password="secret")[0]
    assert not PdfReader(str(un)).is_encrypted and pages(un) == 2


def test_redact(files, tmp_path):
    out = run("redact", [files / "b.pdf"], tmp_path, terms="budget", emails=True)[0]
    text = "".join(p.extract_text() for p in PdfReader(str(out)).pages)
    assert "alice@example.com" not in text and "budget" not in text
    pil = pdfium.PdfDocument(str(out))[0].render(scale=1).to_pil().convert("L")
    assert pil.getextrema()[0] == 0  # black boxes present
    with pytest.raises(ToolError):
        run("redact", [files / "b.pdf"], tmp_path, terms="zzzznotthere")


def test_compare_summarize(files, tmp_path):
    out = run("compare", [files / "b.pdf", files / "b2.pdf"], tmp_path)[0]
    assert "Completely different" in out.read_text(encoding="utf-8").replace("&nbsp;", " ")
    from core.tools_ai import summarize_text
    sample = ("Soil media for horticulture should drain well and hold moisture. " * 3 +
              "Cocopeat is a popular soilless growing medium for nursery seedlings. "
              "Perlite improves aeration in potting mixtures used by nurseries. "
              "Vermicompost adds nutrients to the growing medium. ") * 4
    pts, kw = summarize_text(sample, 3)
    assert 1 <= len(pts) <= 3 and "medium" in kw
    with pytest.raises(ToolError):
        run("summarize", [files / "b2.pdf"], tmp_path)
    s = run("summarize", [files / "a.pdf"], tmp_path)[0]
    assert s.read_text(encoding="utf-8").startswith("# Summary")


def test_ocr(files, tmp_path):
    import shutil
    if not shutil.which("tesseract"):
        pytest.skip("tesseract not installed")
    from PIL import ImageDraw, ImageFont
    im = Image.new("RGB", (1240, 400), "white")
    d = ImageDraw.Draw(im)
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 60)
    d.text((40, 100), "Cocopeat growing medium", fill="black", font=f)
    im.save(tmp_path / "scan.png")
    scan = run("jpg_to_pdf", [tmp_path / "scan.png"], tmp_path, name="scan")[0]
    out = run("ocr", [scan], tmp_path)[0]
    assert "growing" in PdfReader(str(out)).pages[0].extract_text().lower()


def test_planned_tools_refuse():
    with pytest.raises(ToolError):
        execute(TOOLS["translate"], [], {}, "/tmp/x")
