"""Shared helpers: page ranges, output names, overlays, external tool discovery."""
from __future__ import annotations

import io
import os
import re
import shutil
import sys
from pathlib import Path

from .registry import ToolError


# ---------------------------------------------------------------- files / names
def validate_inputs(tool, paths):
    if len(paths) < tool.min_files:
        need = "files" if tool.min_files > 1 else "file"
        raise ToolError(f"{tool.name} needs at least {tool.min_files} {need}.")
    if tool.max_files is not None and len(paths) > tool.max_files:
        raise ToolError(f"{tool.name} accepts at most {tool.max_files} file(s).")
    exts = tool.extensions
    for p in paths:
        if not p.exists():
            raise ToolError(f"File not found: {p}")
        if exts and p.suffix.lower() not in exts:
            raise ToolError(f"{p.name} is not a supported file for {tool.name}.")


def unique_path(folder, stem: str, ext: str) -> Path:
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", stem).strip() or "output"
    p = folder / f"{safe}{ext}"
    i = 2
    while p.exists():
        p = folder / f"{safe}_{i}{ext}"
        i += 1
    return p


def for_each(ctx, fn):
    """Run fn(path) for every input, collecting outputs and reporting progress."""
    outs = []
    n = len(ctx.inputs)
    for i, p in enumerate(ctx.inputs):
        if ctx.cancelled():
            raise ToolError("Cancelled.")
        ctx.log(f"Working on {p.name}")
        res = fn(p)
        outs += res if isinstance(res, list) else [res]
        ctx.progress((i + 1) / n)
    return outs


def human_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024


# ---------------------------------------------------------------- page ranges
def parse_pages(spec, n: int) -> list[int]:
    """'1-3, 5, 8-last' -> zero-based indices, in the order written.

    Empty spec means all pages. A reversed range (5-3) yields descending pages.
    """
    spec = (spec or "").strip().lower()
    if not spec or spec == "all":
        return list(range(n))
    spec = spec.replace("last", str(n)).replace("first", "1")
    out: list[int] = []
    for part in re.split(r"[,;\s]+", spec):
        if not part:
            continue
        try:
            if "-" in part:
                a, b = part.split("-", 1)
                a = int(a) if a else 1
                b = int(b) if b else n
            else:
                a = b = int(part)
        except ValueError:
            raise ToolError(f"'{part}' is not a valid page or range.")
        if min(a, b) < 1 or max(a, b) > n:
            raise ToolError(f"Page range {part} is outside this document (1-{n}).")
        step = 1 if a <= b else -1
        out.extend(range(a - 1, b - 1 + step, step))
    if not out:
        raise ToolError("No pages selected.")
    return out


def open_reader(path, password: str | None = None):
    from pypdf import PdfReader
    try:
        r = PdfReader(str(path), strict=False)
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"Could not open {Path(path).name}: {e}")
    if r.is_encrypted:
        ok = False
        try:
            ok = bool(r.decrypt(password or ""))
        except Exception:  # noqa: BLE001
            ok = False
        if not ok:
            raise ToolError(f"{Path(path).name} is password protected. Use Unlock PDF first.")
    return r


# ---------------------------------------------------------------- overlays
_FONT = None


def font_name() -> str:
    """A Unicode-capable TTF if one can be found, else Helvetica."""
    global _FONT
    if _FONT:
        return _FONT
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    here = Path(__file__).resolve().parent.parent / "assets" / "fonts"
    candidates = [
        here / "NotoSans-Regular.ttf",
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "segoeui.ttf",
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / "arial.ttf",
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        Path("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"),
        Path("/Library/Fonts/Arial.ttf"),
    ]
    for c in candidates:
        try:
            if c.exists():
                pdfmetrics.registerFont(TTFont("AppFont", str(c)))
                _FONT = "AppFont"
                return _FONT
        except Exception:  # noqa: BLE001
            continue
    _FONT = "Helvetica"
    return _FONT


def hex_color(value: str, default="#000000"):
    from reportlab.lib.colors import HexColor
    try:
        return HexColor(value if value.startswith("#") else "#" + value)
    except Exception:  # noqa: BLE001
        return HexColor(default)


def visible_box(page):
    """Visible area of a page: (left, bottom, width, height) before /Rotate."""
    box = page.cropbox
    return float(box.left), float(box.bottom), float(box.width), float(box.height)


def visible_size(page) -> tuple[float, float]:
    _, _, w, h = visible_box(page)
    if page.rotation % 180:
        w, h = h, w
    return w, h


def stamp(page, draw):
    """Draw on top of a page using reportlab, correct for rotated/cropped pages.

    draw(canvas, width, height) receives the *visible* page size with the
    origin at the bottom-left as the reader sees it.
    """
    from pypdf import PdfReader, Transformation
    from reportlab.pdfgen import canvas

    left, bottom, uw, uh = visible_box(page)
    rot = page.rotation % 360
    vw, vh = (uh, uw) if rot % 180 else (uw, uh)
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(vw, vh))
    draw(c, vw, vh)
    c.showPage()
    c.save()
    buf.seek(0)
    overlay = PdfReader(buf).pages[0]
    if rot == 0:
        t = Transformation().translate(left, bottom)
    elif rot == 90:
        t = Transformation().rotate(90).translate(uw + left, bottom)
    elif rot == 180:
        t = Transformation().rotate(180).translate(uw + left, uh + bottom)
    else:
        t = Transformation().rotate(270).translate(left, uh + bottom)
    page.merge_transformed_page(overlay, t)


ANCHORS = ["Bottom center", "Bottom right", "Bottom left", "Top center", "Top right", "Top left"]


def anchor_xy(pos: str, w: float, h: float, tw: float, th: float, margin: float):
    pos = pos.lower()
    if "left" in pos:
        x = margin
    elif "right" in pos:
        x = w - margin - tw
    else:
        x = (w - tw) / 2
    y = h - margin - th if "top" in pos else margin
    return x, y


# ---------------------------------------------------------------- external programs
def _app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


def find_program(names: list[str], extra: list[str] | None = None) -> str | None:
    """Look next to the app (bundled), on PATH, then in usual install folders."""
    bundled = _app_dir() / "third_party"
    for n in names:
        for sub in (bundled, bundled / "bin"):
            for ext in ("", ".exe"):
                p = sub / (n + ext)
                if p.exists():
                    return str(p)
        w = shutil.which(n)
        if w:
            return w
    for e in extra or []:
        if Path(e).exists():
            return e
    return None


def find_soffice() -> str | None:
    pf = [os.environ.get("ProgramFiles", r"C:\Program Files"),
          os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")]
    extra = [str(Path(p) / "LibreOffice" / "program" / "soffice.exe") for p in pf]
    extra.append("/Applications/LibreOffice.app/Contents/MacOS/soffice")
    return find_program(["soffice", "libreoffice"], extra)


def find_tesseract() -> str | None:
    pf = [os.environ.get("ProgramFiles", r"C:\Program Files"),
          os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")]
    extra = [str(Path(p) / "Tesseract-OCR" / "tesseract.exe") for p in pf]
    return find_program(["tesseract"], extra)


def find_ghostscript() -> str | None:
    return find_program(["gswin64c", "gswin32c", "gs"])
