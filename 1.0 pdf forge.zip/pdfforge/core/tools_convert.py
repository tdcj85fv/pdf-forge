from __future__ import annotations

import io
import shutil
import subprocess
import tempfile
from pathlib import Path

from .registry import Field, ToolError, register
from .util import (find_ghostscript, find_soffice, for_each, open_reader, unique_path)


# =============================================================== to PDF
def _prepare_image(path: Path, tmp: Path) -> str:
    """Return a path img2pdf can embed (fixing alpha, EXIF rotation, odd formats)."""
    from PIL import Image, ImageOps
    im = Image.open(path)
    exif_rot = False
    try:
        exif_rot = im.getexif().get(274, 1) not in (None, 1)
    except Exception:  # noqa: BLE001
        pass
    if im.format == "JPEG" and im.mode in ("RGB", "L") and not exif_rot:
        return str(path)
    im = ImageOps.exif_transpose(im)
    if im.mode in ("RGBA", "LA") or (im.mode == "P" and "transparency" in im.info):
        im = im.convert("RGBA")
        bg = Image.new("RGB", im.size, "white")
        bg.paste(im, mask=im.split()[-1])
        im = bg
    elif im.mode not in ("RGB", "L"):
        im = im.convert("RGB")
    out = tmp / f"{path.stem}_{abs(hash(str(path)))}.png"
    im.save(out)
    return str(out)


@register(
    id="jpg_to_pdf", name="JPG to PDF", category="to_pdf", short="JPG", inputs="image", reorder=True,
    desc="Convert JPG, PNG and other images into a PDF.",
    keywords="image picture photo png jpeg convert to pdf tiff bmp webp",
    fields=[
        Field("merge", "Combine all images into one PDF", "bool", True),
        Field("size", "Page size", "choice", "Fit to image", ["Fit to image", "A4", "US Letter"]),
        Field("orient", "Orientation", "choice", "Auto", ["Auto", "Portrait", "Landscape"]),
        Field("margin", "Margin", "choice", "None", ["None", "Small", "Big"]),
        Field("name", "Output file name", "text", "images"),
    ],
)
def jpg_to_pdf(ctx):
    import img2pdf
    o = ctx.opts
    sizes = {"A4": (img2pdf.mm_to_pt(210), img2pdf.mm_to_pt(297)),
             "US Letter": (img2pdf.in_to_pt(8.5), img2pdf.in_to_pt(11))}
    page = sizes.get(o["size"])
    if page and o["orient"] == "Landscape":
        page = (page[1], page[0])
    border = {"None": 0, "Small": img2pdf.mm_to_pt(10), "Big": img2pdf.mm_to_pt(20)}[o["margin"]]
    layout = img2pdf.get_layout_fun(pagesize=page, border=(border, border) if page else None,
                                    fit=img2pdf.FitMode.into, auto_orient=(o["orient"] == "Auto"))
    with tempfile.TemporaryDirectory() as td:
        tmp = Path(td)
        prepared = []
        for i, p in enumerate(ctx.inputs):
            try:
                prepared.append(_prepare_image(p, tmp))
            except Exception as e:  # noqa: BLE001
                raise ToolError(f"Could not read {p.name}: {e}")
            ctx.progress((i + 1) / (2 * len(ctx.inputs)))
        outs = []
        if o["merge"] or len(prepared) == 1:
            out = unique_path(ctx.out_dir, o["name"] or "images", ".pdf")
            out.write_bytes(img2pdf.convert(prepared, layout_fun=layout))
            outs.append(out)
        else:
            for p, prep in zip(ctx.inputs, prepared):
                out = unique_path(ctx.out_dir, p.stem, ".pdf")
                out.write_bytes(img2pdf.convert([prep], layout_fun=layout))
                outs.append(out)
    return outs


def _office_to_pdf(ctx, what: str):
    exe = find_soffice()
    if not exe:
        raise ToolError(f"Converting {what} needs LibreOffice, which was not found. "
                        "Install LibreOffice (free) and try again; it is detected automatically.")

    def one(p):
        with tempfile.TemporaryDirectory() as td:
            profile = Path(td) / "profile"
            cmd = [exe, f"-env:UserInstallation={profile.as_uri()}", "--headless", "--norestore",
                   "--convert-to", "pdf", "--outdir", td, str(p)]
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            try:
                subprocess.run(cmd, check=True, capture_output=True, timeout=300, creationflags=flags)
            except subprocess.TimeoutExpired:
                raise ToolError(f"Converting {p.name} took too long.")
            except subprocess.CalledProcessError as e:
                raise ToolError(f"LibreOffice failed on {p.name}: {e.stderr.decode(errors='ignore')[:200]}")
            made = Path(td) / (p.stem + ".pdf")
            if not made.exists():
                raise ToolError(f"{p.name} could not be converted.")
            out = unique_path(ctx.out_dir, p.stem, ".pdf")
            shutil.move(str(made), out)
            return out
    return for_each(ctx, one)


@register(id="word_to_pdf", name="Word to PDF", category="to_pdf", short="DOC", inputs="word",
          desc="Convert Word documents (DOC, DOCX) into PDF.",
          keywords="doc docx microsoft word convert odt rtf txt libreoffice")
def word_to_pdf(ctx):
    return _office_to_pdf(ctx, "Word documents")


@register(id="ppt_to_pdf", name="PowerPoint to PDF", category="to_pdf", short="PPT", inputs="ppt",
          desc="Convert PowerPoint presentations (PPT, PPTX) into PDF.",
          keywords="slides presentation powerpoint pptx convert libreoffice")
def ppt_to_pdf(ctx):
    return _office_to_pdf(ctx, "presentations")


@register(id="excel_to_pdf", name="Excel to PDF", category="to_pdf", short="XLS", inputs="excel",
          desc="Convert Excel spreadsheets (XLS, XLSX) into PDF.",
          keywords="spreadsheet xlsx csv sheet convert libreoffice")
def excel_to_pdf(ctx):
    return _office_to_pdf(ctx, "spreadsheets")


@register(id="html_to_pdf", name="HTML to PDF", category="to_pdf", short="HTM", inputs="html",
          desc="Convert a saved web page (HTML file) into PDF.",
          keywords="web page website html url convert print")
def html_to_pdf(ctx):
    return _office_to_pdf(ctx, "HTML pages")


# =============================================================== from PDF
@register(
    id="pdf_to_jpg", name="PDF to JPG", category="from_pdf", short="IMG", inputs="pdf",
    desc="Turn every page into an image, or pull out the pictures embedded in the PDF.",
    keywords="image picture photo png export pages extract images render",
    fields=[
        Field("mode", "What to export", "choice", "Pages as images", ["Pages as images", "Embedded images only"]),
        Field("fmt", "Image format", "choice", "JPG", ["JPG", "PNG"]),
        Field("dpi", "Quality (DPI)", "choice", "150", ["72", "150", "200", "300"]),
    ],
)
def pdf_to_jpg(ctx):
    import pypdfium2 as pdfium

    def one(p):
        folder = ctx.out_dir / f"{p.stem}_images"
        folder.mkdir(parents=True, exist_ok=True)
        ext = ".jpg" if ctx.opts["fmt"] == "JPG" else ".png"
        outs = []
        if ctx.opts["mode"] == "Embedded images only":
            import pikepdf
            from pikepdf import PdfImage
            pdf = pikepdf.open(str(p))
            k = 0
            for pi, page in enumerate(pdf.pages):
                for _, raw in page.images.items():
                    try:
                        k += 1
                        pil = PdfImage(raw).as_pil_image()
                        if ext == ".jpg" and pil.mode not in ("RGB", "L"):
                            pil = pil.convert("RGB")
                        out = unique_path(folder, f"{p.stem}_p{pi + 1}_img{k}", ext)
                        pil.save(out, quality=92)
                        outs.append(out)
                    except Exception:  # noqa: BLE001
                        continue
            if not outs:
                raise ToolError(f"No embedded images found in {p.name}.")
            return outs
        doc = pdfium.PdfDocument(str(p))
        n = len(doc)
        scale = int(ctx.opts["dpi"]) / 72
        for i in range(n):
            pil = doc[i].render(scale=scale).to_pil().convert("RGB")
            out = unique_path(folder, f"{p.stem}_page{i + 1:03d}", ext)
            pil.save(out, quality=92)
            outs.append(out)
            ctx.progress((i + 1) / n)
        return outs
    return for_each(ctx, one)


def _plumber(path):
    import pdfplumber
    try:
        return pdfplumber.open(str(path))
    except Exception as e:  # noqa: BLE001
        raise ToolError(f"Could not read {Path(path).name}: {e}")


@register(
    id="pdf_to_word", name="PDF to Word", category="from_pdf", short="DOCX", inputs="pdf",
    desc="Convert PDF into an editable Word document (text, headings, tables and pictures).",
    keywords="docx doc editable convert microsoft word",
    note="Layout is rebuilt as flowing text. For scanned PDFs, run OCR PDF first.",
)
def pdf_to_word(ctx):
    from docx import Document
    from docx.shared import Inches, Pt
    from . import layout as L

    def one(p):
        with _plumber(p) as pdf:
            pages = [L.extract_page(pg, with_images=True) for pg in pdf.pages]
        body = L.body_size(pages)
        doc = Document()
        doc.styles["Normal"].font.size = Pt(max(8, min(14, body)))
        for pi, lay in enumerate(pages):
            items = []
            for para in L.paragraphs(lay.lines, body):
                items.append((para["top"], "p", para))
            items += [(t.top, "t", t) for t in lay.tables]
            items += [(i.top, "i", i) for i in lay.pics]
            for _, kind, obj in sorted(items, key=lambda x: x[0]):
                if kind == "p":
                    if obj["level"]:
                        doc.add_heading(obj["text"], level=obj["level"])
                    elif L.is_list_item(obj["text"]):
                        txt = obj["text"].lstrip("•·▪●◦-–* ").strip()
                        doc.add_paragraph(txt, style="List Bullet")
                    else:
                        para = doc.add_paragraph()
                        run = para.add_run(obj["text"])
                        run.bold = obj["bold"]
                elif kind == "t":
                    cols = max(len(r) for r in obj.rows)
                    tbl = doc.add_table(rows=0, cols=cols)
                    tbl.style = "Table Grid"
                    for row in obj.rows:
                        cells = tbl.add_row().cells
                        for ci, val in enumerate(row):
                            cells[ci].text = val
                else:
                    buf = io.BytesIO()
                    obj.image.save(buf, "PNG")
                    buf.seek(0)
                    width = min(6.0, (obj.bbox[2] - obj.bbox[0]) / 72)
                    doc.add_picture(buf, width=Inches(max(0.5, width)))
            if pi < len(pages) - 1:
                doc.add_page_break()
            ctx.progress((pi + 1) / len(pages))
        out = unique_path(ctx.out_dir, p.stem, ".docx")
        doc.save(out)
        return out
    return for_each(ctx, one)


@register(
    id="pdf_to_ppt", name="PDF to PowerPoint", category="from_pdf", short="PPT", inputs="pdf",
    desc="Turn PDF pages into PowerPoint slides, as editable text boxes or as pictures.",
    keywords="pptx slides presentation convert powerpoint",
    fields=[Field("mode", "Slide content", "choice", "Editable text", ["Editable text", "Page pictures"],
                  hint="Page pictures looks identical but cannot be edited.")],
)
def pdf_to_ppt(ctx):
    from pptx import Presentation
    from pptx.util import Emu, Pt
    import pypdfium2 as pdfium
    from . import layout as L

    def one(p):
        prs = Presentation()
        with _plumber(p) as pdf:
            first = pdf.pages[0]
            prs.slide_width, prs.slide_height = Emu(int(first.width * 12700)), Emu(int(first.height * 12700))
            doc = pdfium.PdfDocument(str(p)) if ctx.opts["mode"] == "Page pictures" else None
            for i, pg in enumerate(pdf.pages):
                slide = prs.slides.add_slide(prs.slide_layouts[6])
                if doc is not None:
                    buf = io.BytesIO()
                    doc[i].render(scale=2).to_pil().convert("RGB").save(buf, "JPEG", quality=88)
                    buf.seek(0)
                    slide.shapes.add_picture(buf, 0, 0, prs.slide_width, prs.slide_height)
                else:
                    lay = L.extract_page(pg, with_images=True)
                    for pic in lay.pics:
                        buf = io.BytesIO()
                        pic.image.save(buf, "PNG")
                        buf.seek(0)
                        x0, t, x1, b = pic.bbox
                        slide.shapes.add_picture(buf, Emu(int(x0 * 12700)), Emu(int(t * 12700)),
                                                 Emu(int((x1 - x0) * 12700)), Emu(int((b - t) * 12700)))
                    for ln in lay.lines:
                        tb = slide.shapes.add_textbox(Emu(int(ln.x0 * 12700)), Emu(int(ln.top * 12700)),
                                                      Emu(int((ln.x1 - ln.x0 + 8) * 12700)),
                                                      Emu(int((ln.bottom - ln.top) * 12700)))
                        tf = tb.text_frame
                        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
                        tf.word_wrap = False
                        r = tf.paragraphs[0].add_run()
                        r.text = ln.text
                        r.font.size = Pt(max(6, ln.size))
                        r.font.bold = ln.bold
                    for t in lay.tables:
                        rows, cols = len(t.rows), max(len(r) for r in t.rows)
                        x0, top, x1, b = t.bbox
                        shape = slide.shapes.add_table(rows, cols, Emu(int(x0 * 12700)), Emu(int(top * 12700)),
                                                       Emu(int((x1 - x0) * 12700)), Emu(int((b - top) * 12700)))
                        for ri, row in enumerate(t.rows):
                            for ci, val in enumerate(row):
                                shape.table.cell(ri, ci).text = val
                ctx.progress((i + 1) / len(pdf.pages))
        out = unique_path(ctx.out_dir, p.stem, ".pptx")
        prs.save(out)
        return out
    return for_each(ctx, one)


@register(
    id="pdf_to_excel", name="PDF to Excel", category="from_pdf", short="XLS", inputs="pdf",
    desc="Extract tables from a PDF straight into an Excel spreadsheet.",
    keywords="xlsx tables spreadsheet data extract csv convert",
    note="Works best on PDFs with ruled tables. Scanned PDFs need OCR PDF first.",
)
def pdf_to_excel(ctx):
    from openpyxl import Workbook
    from openpyxl.styles import Font

    def one(p):
        wb = Workbook()
        wb.remove(wb.active)
        count = 0
        with _plumber(p) as pdf:
            n = len(pdf.pages)
            for i, pg in enumerate(pdf.pages):
                for k, t in enumerate(pg.find_tables()):
                    rows = t.extract()
                    if not rows:
                        continue
                    ws = wb.create_sheet(f"Page{i + 1}_T{k + 1}"[:31])
                    for r in rows:
                        ws.append([(c or "").replace("\n", " ").strip() for c in r])
                    for c in ws[1]:
                        c.font = Font(bold=True)
                    for col in ws.columns:
                        width = max(len(str(c.value or "")) for c in col)
                        ws.column_dimensions[col[0].column_letter].width = min(60, max(8, width + 2))
                    count += 1
                ctx.progress((i + 1) / n)
            if count == 0:
                ws = wb.create_sheet("Text")
                ctx.log("No tables detected; exporting text lines instead.")
                for pg in pdf.pages:
                    for line in (pg.extract_text() or "").splitlines():
                        ws.append([line])
        out = unique_path(ctx.out_dir, p.stem, ".xlsx")
        wb.save(out)
        ctx.log(f"{p.name}: {count} table(s) exported")
        return out
    return for_each(ctx, one)


@register(
    id="pdf_to_pdfa", name="PDF to PDF/A", category="from_pdf", short="A", inputs="pdf",
    desc="Convert PDFs to the ISO PDF/A format for long-term archiving.",
    keywords="archive archival iso standard preservation pdfa",
    fields=[Field("level", "PDF/A level", "choice", "PDF/A-2b", ["PDF/A-1b", "PDF/A-2b", "PDF/A-3b"])],
    note="Uses Ghostscript, which is bundled with the installer when you tick 'PDF/A support'.",
)
def pdf_to_pdfa(ctx):
    gs = find_ghostscript()
    if not gs:
        raise ToolError("PDF/A conversion needs Ghostscript, which was not found. "
                        "Install Ghostscript (free) or re-run the installer with 'PDF/A support' ticked.")
    level = ctx.opts["level"][5]  # 1, 2 or 3

    def one(p):
        out = unique_path(ctx.out_dir, p.stem + "_pdfa", ".pdf")
        cmd = [gs, f"-dPDFA={level}", "-dBATCH", "-dNOPAUSE", "-dQUIET", "-dNOOUTERSAVE",
               "-sColorConversionStrategy=RGB", "-sDEVICE=pdfwrite", "-dPDFACompatibilityPolicy=1",
               f"-sOutputFile={out}", str(p)]
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            subprocess.run(cmd, check=True, capture_output=True, timeout=600, creationflags=flags)
        except subprocess.CalledProcessError as e:
            raise ToolError(f"Ghostscript failed on {p.name}: {e.stderr.decode(errors='ignore')[:200]}")
        return out
    return for_each(ctx, one)


@register(
    id="pdf_to_markdown", name="PDF to Markdown", category="from_pdf", short="MD", inputs="pdf",
    desc="Convert a PDF into a Markdown file with headings, lists and tables.",
    keywords="md text headings lists tables convert notes",
)
def pdf_to_markdown(ctx):
    from . import layout as L

    def one(p):
        with _plumber(p) as pdf:
            pages = [L.extract_page(pg) for pg in pdf.pages]
        body = L.body_size(pages)
        md = []
        for lay in pages:
            items = [(para["top"], "p", para) for para in L.paragraphs(lay.lines, body)]
            items += [(t.top, "t", t) for t in lay.tables]
            for _, kind, obj in sorted(items, key=lambda x: x[0]):
                if kind == "p":
                    t = obj["text"]
                    if obj["level"]:
                        md.append("#" * obj["level"] + " " + t)
                    elif L.is_list_item(t):
                        md.append("- " + t.lstrip("•·▪●◦-–* ").strip())
                    else:
                        md.append(f"**{t}**" if obj["bold"] and len(t) < 120 else t)
                else:
                    rows = obj.rows
                    cols = max(len(r) for r in rows)
                    rows = [r + [""] * (cols - len(r)) for r in rows]
                    esc = lambda c: c.replace("|", "\\|")  # noqa: E731
                    lines = ["| " + " | ".join(esc(c) for c in rows[0]) + " |", "|" + "---|" * cols]
                    lines += ["| " + " | ".join(esc(c) for c in r) + " |" for r in rows[1:]]
                    md.append("\n".join(lines))
            md.append("")
        text = "\n\n".join(m for m in md if m)
        out = unique_path(ctx.out_dir, p.stem, ".md")
        out.write_text(text + "\n", encoding="utf-8")
        return out
    return for_each(ctx, one)
