"""Reading order extraction (text lines, tables, images) shared by the Word, PowerPoint and Markdown exporters."""
from __future__ import annotations

import statistics
from collections import Counter
from dataclasses import dataclass, field


@dataclass
class Line:
    top: float
    bottom: float
    x0: float
    x1: float
    size: float
    bold: bool
    text: str


@dataclass
class Table:
    top: float
    bbox: tuple
    rows: list


@dataclass
class Pic:
    top: float
    bbox: tuple
    image: object  # PIL.Image


@dataclass
class PageLayout:
    width: float
    height: float
    lines: list = field(default_factory=list)
    tables: list = field(default_factory=list)
    pics: list = field(default_factory=list)


def _inside(cx, cy, bbox):
    x0, top, x1, bottom = bbox
    return x0 <= cx <= x1 and top <= cy <= bottom


def extract_page(page, with_images=False, image_dpi=150) -> PageLayout:
    """page is a pdfplumber page."""
    lay = PageLayout(float(page.width), float(page.height))
    try:
        tables = page.find_tables()
    except Exception:  # noqa: BLE001
        tables = []
    for t in tables:
        rows = [[(c or "").replace("\n", " ").strip() for c in row] for row in t.extract()]
        if rows and any(any(c for c in r) for r in rows):
            lay.tables.append(Table(t.bbox[1], t.bbox, rows))
    boxes = [t.bbox for t in lay.tables]
    try:
        raw = page.extract_text_lines(return_chars=True, strip=True)
    except Exception:  # noqa: BLE001
        raw = []
    for ln in raw:
        text = ln["text"].strip()
        if not text:
            continue
        cx, cy = (ln["x0"] + ln["x1"]) / 2, (ln["top"] + ln["bottom"]) / 2
        if any(_inside(cx, cy, b) for b in boxes):
            continue
        chars = ln.get("chars") or []
        sizes = [c.get("size", 0) for c in chars if c.get("text", "").strip()] or [10]
        bold = sum("bold" in c.get("fontname", "").lower() or "black" in c.get("fontname", "").lower()
                   for c in chars) > len(chars) * 0.6 if chars else False
        lay.lines.append(Line(ln["top"], ln["bottom"], ln["x0"], ln["x1"],
                              statistics.median(sizes), bold, text))
    if with_images:
        for im in page.images:
            try:
                x0, top = max(0, im["x0"]), max(0, im["top"])
                x1, bottom = min(page.width, im["x1"]), min(page.height, im["bottom"])
                if x1 - x0 < 12 or bottom - top < 12:
                    continue
                pil = page.crop((x0, top, x1, bottom)).to_image(resolution=image_dpi).original
                lay.pics.append(Pic(top, (x0, top, x1, bottom), pil.convert("RGB")))
            except Exception:  # noqa: BLE001
                continue
    return lay


def body_size(layouts) -> float:
    c = Counter()
    for lay in layouts:
        for ln in lay.lines:
            c[round(ln.size)] += len(ln.text)
    return float(c.most_common(1)[0][0]) if c else 11.0


def heading_level(line: Line, body: float) -> int:
    """0 = normal text, 1-3 = heading levels by relative font size."""
    ratio = line.size / body if body else 1
    if ratio >= 1.6:
        return 1
    if ratio >= 1.35:
        return 2
    if ratio >= 1.15 or (line.bold and len(line.text) < 70 and not line.text.endswith((".", ",", ";"))
                         and ratio >= 1.0 and len(line.text.split()) <= 10):
        return 3
    return 0


def paragraphs(lines: list, body: float):
    """Group consecutive lines of one page into (kind, level, text, bold) paragraphs."""
    out = []
    cur = None
    for ln in sorted(lines, key=lambda l: (round(l.top), l.x0)):
        lvl = heading_level(ln, body)
        gap = ln.top - cur["bottom"] if cur else 0
        join = (cur and not lvl and cur["level"] == 0 and gap < ln.size * 0.9
                and abs(ln.size - cur["size"]) < 1.2 and not _is_list(ln.text))
        if join:
            sep = "" if cur["text"].endswith("-") else " "
            cur["text"] = (cur["text"][:-1] if sep == "" else cur["text"]) + sep + ln.text
            cur["bottom"] = ln.bottom
            continue
        cur = {"top": ln.top, "bottom": ln.bottom, "size": ln.size, "level": lvl,
               "text": ln.text, "bold": ln.bold, "x0": ln.x0}
        out.append(cur)
    return out


def _is_list(text: str) -> bool:
    t = text.lstrip()
    return t[:1] in "•·▪●◦-–*" and len(t) > 1 and t[1] == " " or (
        len(t) > 2 and t[0].isdigit() and t.split(" ")[0].rstrip(".)").isdigit() and t.split(" ")[0][-1] in ".)")


def is_list_item(text: str) -> bool:
    return _is_list(text)
