from __future__ import annotations

import io
import shutil

import pikepdf
from PIL import Image
from pikepdf import Name, PdfImage

from .registry import Field, ToolError, register
from .util import find_tesseract, for_each, human_size, open_reader, unique_path

# longest image side in pixels, JPEG quality
_LEVELS = {"low": (2400, 85), "recommended": (1600, 65), "extreme": (1000, 40)}


def _recompress_images(pdf: pikepdf.Pdf, max_side: int, quality: int) -> int:
    seen = set()
    changed = 0
    for page in pdf.pages:
        try:
            images = list(page.images.items())
        except Exception:  # noqa: BLE001
            continue
        for _, raw in images:
            if raw.objgen in seen:
                continue
            seen.add(raw.objgen)
            try:
                if any(k in raw for k in ("/SMask", "/Mask", "/ImageMask")):
                    continue
                pil = PdfImage(raw).as_pil_image()
                if pil.mode == "P":
                    pil = pil.convert("RGB")
                if pil.mode not in ("RGB", "L"):
                    continue
                scale = min(1.0, max_side / max(pil.size))
                if scale < 1:
                    pil = pil.resize((max(1, int(pil.width * scale)), max(1, int(pil.height * scale))),
                                     Image.LANCZOS)
                buf = io.BytesIO()
                pil.save(buf, "JPEG", quality=quality, optimize=True)
                data = buf.getvalue()
                if len(data) >= len(raw.read_raw_bytes()) * 0.95:
                    continue
                raw.write(data, filter=Name.DCTDecode)
                raw.Width, raw.Height = pil.width, pil.height
                raw.ColorSpace = Name.DeviceRGB if pil.mode == "RGB" else Name.DeviceGray
                raw.BitsPerComponent = 8
                if "/Decode" in raw:
                    del raw["/Decode"]
                if "/DecodeParms" in raw:
                    del raw["/DecodeParms"]
                changed += 1
            except Exception:  # noqa: BLE001
                continue
    return changed


@register(
    id="compress", name="Compress PDF", category="optimize", short="CP", inputs="pdf",
    desc="Reduce file size while keeping the best possible quality.",
    keywords="smaller shrink reduce size optimize email",
    fields=[Field("level", "Compression level", "choice", "Recommended", ["Low", "Recommended", "Extreme"],
                  hint="Low keeps the most quality. Extreme gives the smallest file.")],
)
def compress(ctx):
    max_side, quality = _LEVELS[ctx.opts["level"].lower()]

    def one(p):
        try:
            pdf = pikepdf.open(str(p))
        except pikepdf.PasswordError:
            raise ToolError(f"{p.name} is password protected. Use Unlock PDF first.")
        n = _recompress_images(pdf, max_side, quality)
        pdf.remove_unreferenced_resources()
        out = unique_path(ctx.out_dir, p.stem + "_compressed", ".pdf")
        pdf.save(str(out), compress_streams=True, recompress_flate=True,
                 object_stream_mode=pikepdf.ObjectStreamMode.generate)
        before, after = p.stat().st_size, out.stat().st_size
        if after >= before:
            shutil.copyfile(p, out)
            ctx.log(f"{p.name}: already well optimized ({human_size(before)}), kept as is.")
        else:
            ctx.log(f"{p.name}: {human_size(before)} -> {human_size(after)} "
                    f"({100 - after * 100 // before}% smaller, {n} images re-encoded)")
        return out
    return for_each(ctx, one)


@register(
    id="repair", name="Repair PDF", category="optimize", short="RP", inputs="pdf",
    desc="Fix damaged or corrupt PDF files and recover what can be saved.",
    keywords="fix corrupt damaged broken recover cannot open",
)
def repair(ctx):
    def one(p):
        out = unique_path(ctx.out_dir, p.stem + "_repaired", ".pdf")
        try:
            pdf = pikepdf.open(str(p), attempt_recovery=True)
            pdf.save(str(out))
            ctx.log(f"{p.name}: rebuilt with {len(pdf.pages)} pages")
            return out
        except pikepdf.PasswordError:
            raise ToolError(f"{p.name} is password protected. Use Unlock PDF first.")
        except Exception as first:  # noqa: BLE001
            try:  # second opinion: a more forgiving parser
                from pypdf import PdfReader, PdfWriter
                r = PdfReader(str(p), strict=False)
                w = PdfWriter()
                for page in r.pages:
                    w.add_page(page)
                with open(out, "wb") as f:
                    w.write(f)
                ctx.log(f"{p.name}: recovered {len(r.pages)} pages with the fallback reader")
                return out
            except Exception:  # noqa: BLE001
                raise ToolError(f"{p.name} could not be repaired ({first}).")
    return for_each(ctx, one)


@register(
    id="ocr", name="OCR PDF", category="optimize", short="OCR", inputs="pdf",
    desc="Turn scanned PDFs into searchable, selectable text. Runs fully on this computer.",
    keywords="scan text recognize searchable selectable tesseract image to text",
    fields=[
        Field("lang", "Language code(s)", "text", "eng",
              hint="Tesseract codes, e.g. eng, hin, mar, deu. Combine with +, e.g. eng+hin."),
        Field("skip_text", "Skip pages that already contain text", "bool", True),
    ],
)
def ocr(ctx):
    exe = find_tesseract()
    if not exe:
        raise ToolError("OCR needs Tesseract, which was not found. Re-run the installer and tick "
                        "'OCR engine', or install Tesseract-OCR and try again.")
    import pypdfium2 as pdfium
    import pytesseract
    from pypdf import PdfReader, PdfWriter
    pytesseract.pytesseract.tesseract_cmd = exe

    def one(p):
        src = pdfium.PdfDocument(str(p))
        orig = open_reader(p)
        w = PdfWriter()
        n = len(src)
        for i in range(n):
            if ctx.cancelled():
                raise ToolError("Cancelled.")
            page = src[i]
            has_text = False
            if ctx.opts["skip_text"]:
                tp = page.get_textpage()
                has_text = tp.count_chars() > 25
            if has_text:
                w.add_page(orig.pages[i])
            else:
                img = page.render(scale=300 / 72).to_pil().convert("RGB")
                data = pytesseract.image_to_pdf_or_hocr(img, lang=ctx.opts["lang"] or "eng", extension="pdf")
                new = PdfReader(io.BytesIO(data)).pages[0]
                ow, oh = float(orig.pages[i].cropbox.width), float(orig.pages[i].cropbox.height)
                new.scale_to(ow, oh)
                w.add_page(new)
            ctx.progress((i + 1) / n)
        out = unique_path(ctx.out_dir, p.stem + "_ocr", ".pdf")
        with open(out, "wb") as f:
            w.write(f)
        return out
    return for_each(ctx, one)
