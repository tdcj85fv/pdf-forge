"""Tool registry: every PDF feature is a Tool with a declarative option form.

The UI builds its pages from these declarations, so adding a new tool means
writing one function and one @register(...) line, nothing else.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

CATEGORIES = [
    ("organize", "Organize PDF"),
    ("optimize", "Optimize & Repair"),
    ("to_pdf", "Convert to PDF"),
    ("from_pdf", "Convert from PDF"),
    ("edit", "Edit PDF"),
    ("security", "PDF Security"),
    ("ai", "PDF Intelligence"),
    ("other", "Workflows & More"),
]
CATEGORY_NAMES = dict(CATEGORIES)

INPUT_EXTS = {
    "pdf": [".pdf"],
    "image": [".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp", ".gif"],
    "word": [".doc", ".docx", ".odt", ".rtf", ".txt"],
    "ppt": [".ppt", ".pptx", ".odp"],
    "excel": [".xls", ".xlsx", ".ods", ".csv"],
    "html": [".html", ".htm"],
    "any": [],
}
INPUT_LABELS = {
    "pdf": "PDF files", "image": "Images", "word": "Word documents",
    "ppt": "PowerPoint files", "excel": "Excel files", "html": "HTML files", "any": "Files",
}


@dataclass
class Field:
    """One option shown on a tool page.

    kind: text | multiline | int | float | bool | choice | pages | file | password
    """
    key: str
    label: str
    kind: str = "text"
    default: object = ""
    choices: list = field(default_factory=list)
    hint: str = ""
    filt: str = ""          # file dialog filter for kind == "file"
    required: bool = False
    minimum: float = 0
    maximum: float = 100000


@dataclass
class Ctx:
    """What a tool receives when it runs."""
    inputs: list
    opts: dict
    out_dir: Path
    log: Callable[[str], None] = lambda m: None
    progress: Callable[[float], None] = lambda f: None
    cancelled: Callable[[], bool] = lambda: False


@dataclass
class Tool:
    id: str
    name: str
    category: str
    desc: str
    run: Optional[Callable[[Ctx], list]] = None
    keywords: str = ""
    inputs: str = "pdf"
    min_files: int = 1
    max_files: Optional[int] = None     # None = any number
    fields: list = field(default_factory=list)
    available: bool = True
    note: str = ""
    short: str = "PDF"                  # badge text on the card
    reorder: bool = False               # UI shows move up/down for the file list

    @property
    def extensions(self):
        return INPUT_EXTS[self.inputs]

    def defaults(self) -> dict:
        return {f.key: f.default for f in self.fields}


TOOLS: dict[str, Tool] = {}


def register(**kw):
    def deco(fn):
        t = Tool(run=fn, **kw)
        TOOLS[t.id] = t
        return fn
    return deco


def planned(**kw):
    """A tool that is listed (and searchable) but not built yet."""
    t = Tool(run=None, available=False, **kw)
    TOOLS[t.id] = t


def by_category() -> list[tuple[str, str, list[Tool]]]:
    out = []
    for cid, cname in CATEGORIES:
        items = [t for t in TOOLS.values() if t.category == cid]
        if items:
            out.append((cid, cname, items))
    return out


def search(query: str) -> list[Tool]:
    """Rank tools against a free-text query (name > keywords > description)."""
    words = [w for w in query.lower().replace("-", " ").split() if w]
    if not words:
        return list(TOOLS.values())
    scored = []
    for t in TOOLS.values():
        name = t.name.lower()
        kw = t.keywords.lower()
        desc = t.desc.lower()
        cat = CATEGORY_NAMES.get(t.category, "").lower()
        score = 0
        for w in words:
            if w in name:
                score += 10 + (5 if name.startswith(w) else 0)
            elif w in kw:
                score += 6
            elif w in desc:
                score += 3
            elif w in cat:
                score += 1
            else:
                score = -1
                break
        if score > 0:
            scored.append((score, t))
    scored.sort(key=lambda s: (-s[0], s[1].name))
    return [t for _, t in scored]


class ToolError(Exception):
    """A problem the user can understand and fix (bad page range, wrong password...)."""


def execute(tool: Tool, inputs, opts: dict, out_dir, log=None, progress=None, cancelled=None):
    """Validate input and run a tool. Returns the list of output paths."""
    from .util import validate_inputs
    if not tool.available or tool.run is None:
        raise ToolError(f"{tool.name} is not available yet.")
    paths = [Path(p) for p in inputs]
    validate_inputs(tool, paths)
    merged = tool.defaults()
    merged.update(opts or {})
    for f in tool.fields:
        if f.required and not str(merged.get(f.key, "")).strip():
            raise ToolError(f"Please fill in: {f.label}")
    ctx = Ctx(
        inputs=paths, opts=merged, out_dir=Path(out_dir),
        log=log or (lambda m: None),
        progress=progress or (lambda f: None),
        cancelled=cancelled or (lambda: False),
    )
    ctx.out_dir.mkdir(parents=True, exist_ok=True)
    return [Path(p) for p in tool.run(ctx)]
