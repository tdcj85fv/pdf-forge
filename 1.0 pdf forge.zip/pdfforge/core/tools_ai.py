from __future__ import annotations

import re
from collections import Counter

from .registry import Field, ToolError, planned, register
from .util import for_each, unique_path

_STOP = set("""a about above after again all also am an and any are as at be because been before being below between both but
by can could did do does doing down during each few for from further had has have having he her here hers him his how i if in
into is it its itself just me more most my no nor not now of off on once only or other our out over own same she should so some
such than that the their theirs them then there these they this those through to too under until up very was we were what when
where which while who whom why will with would you your yours""".split())


def _text(path) -> str:
    import pdfplumber
    parts = []
    with pdfplumber.open(str(path)) as pdf:
        for pg in pdf.pages:
            parts.append(pg.extract_text() or "")
    return "\n".join(parts)


def summarize_text(text: str, k: int = 7):
    text = re.sub(r"\s+", " ", text).strip()
    sents = [s.strip() for s in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9“\"'])", text) if 30 <= len(s.strip()) <= 400]
    if not sents:
        return [], []
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z'-]{2,}", text.lower()) if w not in _STOP]
    freq = Counter(words)
    if not freq:
        return sents[:k], []
    top = freq.most_common(1)[0][1]
    scored = []
    for i, s in enumerate(sents):
        toks = [w for w in re.findall(r"[A-Za-z][A-Za-z'-]{2,}", s.lower()) if w not in _STOP]
        if not toks:
            continue
        score = sum(freq[t] / top for t in toks) / (len(toks) ** 0.6)
        if i < 3:
            score *= 1.15  # openings usually frame the document
        scored.append((score, i, s))
    best = sorted(sorted(scored, reverse=True)[:k], key=lambda x: x[1])
    return [s for _, _, s in best], [w for w, _ in freq.most_common(10)]


@register(
    id="summarize", name="AI Summarizer", category="ai", short="AI", inputs="pdf",
    desc="Get the key points of a PDF as a short summary. Runs on your computer, no upload.",
    keywords="summary summarise tldr key points insights abstract overview",
    fields=[Field("points", "Number of key points", "int", 7, minimum=3, maximum=25)],
    note="Offline extractive summary: it selects the most important sentences from the document.",
)
def summarize(ctx):
    def one(p):
        text = _text(p)
        if len(text.strip()) < 200:
            raise ToolError(f"{p.name} has too little text. If it is a scan, run OCR PDF first.")
        points, keywords = summarize_text(text, int(ctx.opts["points"]))
        md = [f"# Summary of {p.name}", "", "## Key points", ""]
        md += [f"- {s}" for s in points]
        if keywords:
            md += ["", "## Frequent topics", "", ", ".join(keywords)]
        out = unique_path(ctx.out_dir, p.stem + "_summary", ".md")
        out.write_text("\n".join(md) + "\n", encoding="utf-8")
        return out
    return for_each(ctx, one)


planned(
    id="translate", name="Translate PDF", category="ai", short="TR", inputs="pdf",
    desc="Translate a whole PDF into another language while keeping its layout.",
    keywords="language convert hindi marathi spanish french german english",
    note="Planned. Needs downloadable offline language packs to stay fully on-device.",
)
planned(
    id="workflows", name="Workflows", category="other", short="WF", inputs="any",
    desc="Chain several tools into a reusable routine, e.g. compress, then watermark, then protect.",
    keywords="automate batch chain routine pipeline macro",
    note="Planned for the next round: build, save and run your own tool chains.",
)
