from __future__ import annotations

from pypdf import PdfWriter

from .registry import Field, ToolError, register, planned
from .util import for_each, open_reader, parse_pages, unique_path


def _write(writer: PdfWriter, out):
    with open(out, "wb") as f:
        writer.write(f)
    return out


@register(
    id="merge", name="Merge PDF", category="organize", short="MG", inputs="pdf", min_files=2,
    desc="Combine multiple PDF files into one, in the order you choose.",
    keywords="join combine append concatenate together", reorder=True,
    fields=[
        Field("name", "Output file name", "text", "merged"),
        Field("bookmarks", "Add a bookmark for each file", "bool", True),
    ],
)
def merge(ctx):
    w = PdfWriter()
    for i, p in enumerate(ctx.inputs):
        r = open_reader(p)
        w.append(r, outline_item=p.stem if ctx.opts["bookmarks"] else None)
        ctx.progress((i + 1) / len(ctx.inputs))
    return [_write(w, unique_path(ctx.out_dir, ctx.opts["name"] or "merged", ".pdf"))]


@register(
    id="split", name="Split PDF", category="organize", short="SP", inputs="pdf", max_files=1,
    desc="Separate one PDF into several files by ranges, every N pages, or one file per page.",
    keywords="separate divide cut pages ranges",
    fields=[
        Field("mode", "Split by", "choice", "Custom ranges", ["Custom ranges", "Every N pages", "Each page"]),
        Field("value", "Ranges or N", "text", "1-3, 4-6",
              hint="Ranges: each comma-separated range becomes its own file, e.g. 1-3, 5, 7-last. "
                   "Every N pages: enter a number."),
    ],
)
def split(ctx):
    p = ctx.inputs[0]
    r = open_reader(p)
    n = len(r.pages)
    mode = ctx.opts["mode"]
    value = str(ctx.opts["value"]).strip()
    if mode == "Each page":
        groups = [[i] for i in range(n)]
    elif mode == "Every N pages":
        try:
            k = int(value or 1)
        except ValueError:
            raise ToolError("Enter a whole number for N.")
        if k < 1:
            raise ToolError("N must be at least 1.")
        groups = [list(range(i, min(i + k, n))) for i in range(0, n, k)]
    else:
        groups = [parse_pages(part, n) for part in value.split(",") if part.strip()]
        if not groups:
            raise ToolError("Enter at least one page range.")
    folder = ctx.out_dir / f"{p.stem}_split"
    outs = []
    for gi, g in enumerate(groups):
        w = PdfWriter()
        for i in g:
            w.add_page(r.pages[i])
        outs.append(_write(w, unique_path(folder, f"{p.stem}_part{gi + 1}", ".pdf")))
        ctx.progress((gi + 1) / len(groups))
    ctx.log(f"Created {len(outs)} files in {folder.name}")
    return outs


@register(
    id="remove_pages", name="Remove Pages", category="organize", short="RM", inputs="pdf",
    desc="Delete the pages you don't want from a PDF.",
    keywords="delete drop discard pages",
    fields=[Field("pages", "Pages to remove", "pages", "", hint="e.g. 2, 5-7, last", required=True)],
)
def remove_pages(ctx):
    def one(p):
        r = open_reader(p)
        n = len(r.pages)
        drop = set(parse_pages(ctx.opts["pages"], n))
        keep = [i for i in range(n) if i not in drop]
        if not keep:
            raise ToolError("That would remove every page.")
        w = PdfWriter()
        for i in keep:
            w.add_page(r.pages[i])
        return _write(w, unique_path(ctx.out_dir, p.stem + "_removed", ".pdf"))
    return for_each(ctx, one)


@register(
    id="extract_pages", name="Extract Pages", category="organize", short="EX", inputs="pdf",
    desc="Pull specific pages out of a PDF and save them as a new file.",
    keywords="select take copy pages",
    fields=[
        Field("pages", "Pages to extract", "pages", "", hint="e.g. 1-3, 8, last", required=True),
        Field("separate", "Save every page as its own file", "bool", False),
    ],
)
def extract_pages(ctx):
    def one(p):
        r = open_reader(p)
        idx = parse_pages(ctx.opts["pages"], len(r.pages))
        if ctx.opts["separate"]:
            outs = []
            for i in idx:
                w = PdfWriter()
                w.add_page(r.pages[i])
                outs.append(_write(w, unique_path(ctx.out_dir, f"{p.stem}_page{i + 1}", ".pdf")))
            return outs
        w = PdfWriter()
        for i in idx:
            w.add_page(r.pages[i])
        return _write(w, unique_path(ctx.out_dir, p.stem + "_extracted", ".pdf"))
    return for_each(ctx, one)


@register(
    id="organize", name="Organize PDF", category="organize", short="OR", inputs="pdf", max_files=1,
    desc="Re-order, duplicate or drop pages by typing the new page order.",
    keywords="sort rearrange reorder reverse move pages",
    fields=[Field("order", "New page order", "pages", "reverse",
                  hint="e.g. 3, 1, 2, 4-last. Type 'reverse' to flip the document. "
                       "Pages you leave out are dropped; repeat a page to duplicate it.")],
)
def organize(ctx):
    p = ctx.inputs[0]
    r = open_reader(p)
    n = len(r.pages)
    spec = str(ctx.opts["order"]).strip().lower()
    idx = list(range(n - 1, -1, -1)) if spec == "reverse" else parse_pages(spec, n)
    w = PdfWriter()
    for i in idx:
        w.add_page(r.pages[i])
    return [_write(w, unique_path(ctx.out_dir, p.stem + "_organized", ".pdf"))]


planned(
    id="scan_to_pdf", name="Scan to PDF", category="organize", short="SC",
    desc="Scan paper documents with a connected scanner or webcam and save them as PDF.",
    keywords="scanner camera webcam paper", inputs="image",
    note="Planned. Until then, photograph pages and use JPG to PDF.",
)
