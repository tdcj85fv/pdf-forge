from __future__ import annotations

from datetime import date
from pathlib import Path

from pypdf import PdfWriter
from pypdf.generic import RectangleObject

from .registry import Field, ToolError, register
from .util import (ANCHORS, anchor_xy, font_name, for_each, hex_color, open_reader, parse_pages,
                   stamp, unique_path)


def _save(writer, out):
    with open(out, "wb") as f:
        writer.write(f)
    return out


def _clone(path):
    r = open_reader(path)
    return PdfWriter(clone_from=r)


@register(
    id="rotate", name="Rotate PDF", category="edit", short="RT", inputs="pdf",
    desc="Rotate one, several or all pages.",
    keywords="turn sideways landscape portrait flip upside down",
    fields=[
        Field("angle", "Rotate", "choice", "90° clockwise", ["90° clockwise", "180°", "90° counter-clockwise"]),
        Field("pages", "Pages", "pages", "", hint="Leave empty for all pages. e.g. 1, 3-5"),
    ],
)
def rotate(ctx):
    deg = {"90° clockwise": 90, "180°": 180, "90° counter-clockwise": 270}[ctx.opts["angle"]]

    def one(p):
        w = _clone(p)
        for i in parse_pages(ctx.opts["pages"], len(w.pages)):
            w.pages[i].rotate(deg)
        return _save(w, unique_path(ctx.out_dir, p.stem + "_rotated", ".pdf"))
    return for_each(ctx, one)


@register(
    id="page_numbers", name="Add Page Numbers", category="edit", short="#", inputs="pdf",
    desc="Insert page numbers with your choice of position, format and size.",
    keywords="numbering footer header pagination number pages",
    fields=[
        Field("pos", "Position", "choice", "Bottom center", ANCHORS),
        Field("fmt", "Format", "choice", "Page 1 of N", ["1", "Page 1", "Page 1 of N", "1 / N"]),
        Field("start", "First number", "int", 1, minimum=0, maximum=100000),
        Field("pages", "Number these pages", "pages", "", hint="Leave empty for all pages."),
        Field("size", "Font size", "int", 11, minimum=6, maximum=48),
        Field("margin", "Margin from edge (pt)", "int", 28, minimum=0, maximum=200),
        Field("color", "Colour (hex)", "text", "#333333"),
    ],
)
def page_numbers(ctx):
    o = ctx.opts
    font = font_name()

    def one(p):
        w = _clone(p)
        n = len(w.pages)
        targets = parse_pages(o["pages"], n)
        for k, i in enumerate(targets):
            num = int(o["start"]) + k
            total = int(o["start"]) + len(targets) - 1
            text = {"1": f"{num}", "Page 1": f"Page {num}", "Page 1 of N": f"Page {num} of {total}",
                    "1 / N": f"{num} / {total}"}[o["fmt"]]

            def draw(c, W, H, text=text):
                size = int(o["size"])
                c.setFont(font, size)
                c.setFillColor(hex_color(o["color"], "#333333"))
                tw = c.stringWidth(text, font, size)
                x, y = anchor_xy(o["pos"], W, H, tw, size, float(o["margin"]))
                c.drawString(x, y, text)
            stamp(w.pages[i], draw)
            ctx.progress((k + 1) / len(targets))
        return _save(w, unique_path(ctx.out_dir, p.stem + "_numbered", ".pdf"))
    return for_each(ctx, one)


@register(
    id="watermark", name="Add Watermark", category="edit", short="WM", inputs="pdf",
    desc="Stamp text or an image over your PDF with adjustable transparency and angle.",
    keywords="stamp confidential draft logo overlay text image transparency",
    fields=[
        Field("text", "Watermark text", "text", "CONFIDENTIAL", hint="Leave empty to use an image instead."),
        Field("image", "Watermark image (optional)", "file", "", filt="Images (*.png *.jpg *.jpeg)"),
        Field("opacity", "Opacity (%)", "int", 25, minimum=5, maximum=100),
        Field("angle", "Angle", "choice", "45", ["0", "45", "90", "315"]),
        Field("size", "Text size", "int", 64, minimum=8, maximum=300),
        Field("color", "Text colour (hex)", "text", "#E0245E"),
        Field("layout", "Layout", "choice", "Center", ["Center", "Tiled"]),
        Field("pages", "Pages", "pages", "", hint="Leave empty for all pages."),
    ],
)
def watermark(ctx):
    o = ctx.opts
    text = (o["text"] or "").strip()
    image = o["image"]
    if not text and not image:
        raise ToolError("Enter watermark text or choose an image.")
    font = font_name()
    alpha = max(0.05, min(1.0, int(o["opacity"]) / 100))
    angle = int(o["angle"])
    img = None
    if image:
        from PIL import Image
        from reportlab.lib.utils import ImageReader
        try:
            pil = Image.open(image).convert("RGBA")
        except Exception as e:  # noqa: BLE001
            raise ToolError(f"Could not read the image: {e}")
        img = ImageReader(pil)
        iw, ih = pil.size

    def draw(c, W, H):
        c.saveState()
        c.setFillAlpha(alpha)
        c.setFillColor(hex_color(o["color"], "#E0245E"))
        spots = [(W / 2, H / 2)]
        if o["layout"] == "Tiled":
            gx, gy = max(W / 3, 140), max(H / 4, 140)
            spots = [(x, y) for x in _frange(gx / 2, W + gx, gx) for y in _frange(gy / 2, H + gy, gy)]
        for (x, y) in spots:
            c.saveState()
            c.translate(x, y)
            c.rotate(angle)
            if img is not None:
                width = (W * (0.28 if o["layout"] == "Tiled" else 0.55))
                height = width * ih / iw
                c.drawImage(img, -width / 2, -height / 2, width, height, mask="auto")
            else:
                size = int(o["size"]) * (0.6 if o["layout"] == "Tiled" else 1)
                c.setFont(font, size)
                c.drawCentredString(0, -size / 3, text)
            c.restoreState()
        c.restoreState()

    def one(p):
        w = _clone(p)
        targets = parse_pages(o["pages"], len(w.pages))
        for k, i in enumerate(targets):
            stamp(w.pages[i], draw)
            ctx.progress((k + 1) / len(targets))
        return _save(w, unique_path(ctx.out_dir, p.stem + "_watermarked", ".pdf"))
    return for_each(ctx, one)


def _frange(a, b, step):
    x = a
    while x < b:
        yield x
        x += step


@register(
    id="crop", name="Crop PDF", category="edit", short="CR", inputs="pdf",
    desc="Trim margins from every page, or only the pages you choose.",
    keywords="trim margins cut borders whitespace",
    fields=[
        Field("top", "Top (mm)", "float", 10, minimum=0, maximum=500),
        Field("bottom", "Bottom (mm)", "float", 10, minimum=0, maximum=500),
        Field("left", "Left (mm)", "float", 10, minimum=0, maximum=500),
        Field("right", "Right (mm)", "float", 10, minimum=0, maximum=500),
        Field("pages", "Pages", "pages", "", hint="Leave empty for all pages."),
    ],
)
def crop(ctx):
    o = ctx.opts
    mm = 72 / 25.4
    T, B, Lm, R = (float(o[k]) * mm for k in ("top", "bottom", "left", "right"))

    def one(p):
        w = _clone(p)
        for i in parse_pages(o["pages"], len(w.pages)):
            page = w.pages[i]
            b = page.cropbox
            l, bt, r, t = float(b.left), float(b.bottom), float(b.right), float(b.top)
            rot = page.rotation % 360
            # map margins as seen by the reader onto the unrotated page edges
            if rot == 0:
                l += Lm; t -= T; r -= R; bt += B
            elif rot == 90:
                bt += Lm; l += T; t -= R; r -= B
            elif rot == 180:
                l += R; r -= Lm; t -= B; bt += T
            else:
                t -= Lm; r -= T; bt += R; l += B
            if r - l < 10 or t - bt < 10:
                raise ToolError("Those margins leave nothing of the page.")
            page.cropbox = RectangleObject([l, bt, r, t])
        return _save(w, unique_path(ctx.out_dir, p.stem + "_cropped", ".pdf"))
    return for_each(ctx, one)


@register(
    id="edit_pdf", name="Edit PDF", category="edit", short="ED", inputs="pdf", max_files=1,
    desc="Add text or an image anywhere on your pages.",
    keywords="annotate type write text insert image logo shapes sign add",
    fields=[
        Field("text", "Text to add", "multiline", ""),
        Field("size", "Text size", "int", 14, minimum=6, maximum=200),
        Field("color", "Text colour (hex)", "text", "#000000"),
        Field("image", "Image to add (optional)", "file", "", filt="Images (*.png *.jpg *.jpeg)"),
        Field("img_w", "Image width (mm)", "float", 40, minimum=5, maximum=500),
        Field("x", "Distance from left (mm)", "float", 20, minimum=0, maximum=1000),
        Field("y", "Distance from top (mm)", "float", 20, minimum=0, maximum=1000),
        Field("pages", "Pages", "pages", "1", hint="e.g. 1, 3-5, all"),
    ],
)
def edit_pdf(ctx):
    o = ctx.opts
    text = (o["text"] or "").strip("\n")
    if not text and not o["image"]:
        raise ToolError("Enter some text or choose an image to add.")
    mm = 72 / 25.4
    font = font_name()
    img = None
    if o["image"]:
        from PIL import Image
        from reportlab.lib.utils import ImageReader
        pil = Image.open(o["image"]).convert("RGBA")
        img = (ImageReader(pil), pil.width, pil.height)

    def draw(c, W, H):
        x, ytop = float(o["x"]) * mm, float(o["y"]) * mm
        if img is not None:
            width = float(o["img_w"]) * mm
            height = width * img[2] / img[1]
            c.drawImage(img[0], x, H - ytop - height, width, height, mask="auto")
            ytop += height + 4
        if text:
            size = int(o["size"])
            c.setFont(font, size)
            c.setFillColor(hex_color(o["color"]))
            for k, line in enumerate(text.splitlines()):
                c.drawString(x, H - ytop - size * (k + 1), line)

    p = ctx.inputs[0]
    w = _clone(p)
    for k, i in enumerate(parse_pages(o["pages"], len(w.pages))):
        stamp(w.pages[i], draw)
    return [_save(w, unique_path(ctx.out_dir, p.stem + "_edited", ".pdf"))]


@register(
    id="pdf_forms", name="PDF Forms", category="edit", short="FRM", inputs="pdf", max_files=1,
    desc="Fill in a fillable PDF form, or flatten it so the answers can't be changed.",
    keywords="fillable form fields checkbox text field fill flatten acroform",
    fields=[
        Field("values", "Field values", "multiline", "",
              hint="One per line as name=value. Leave empty to just list the fields in the log."),
        Field("flatten", "Flatten after filling", "bool", False),
    ],
)
def pdf_forms(ctx):
    p = ctx.inputs[0]
    r = open_reader(p)
    fields = r.get_fields() or {}
    if not fields:
        raise ToolError("This PDF has no fillable form fields.")
    ctx.log("Fields found: " + ", ".join(f"{k} ({v.get('/FT', '?')})" for k, v in fields.items()))
    values = {}
    for line in str(ctx.opts["values"]).splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            values[k.strip()] = v.strip()
    unknown = [k for k in values if k not in fields]
    if unknown:
        raise ToolError("Unknown field(s): " + ", ".join(unknown))
    if not values and not ctx.opts["flatten"]:
        raise ToolError("Field list is in the log. Enter values as name=value to fill them in.")
    w = PdfWriter(clone_from=r)
    for page in w.pages:
        w.update_page_form_field_values(page, values, auto_regenerate=False)
    out = unique_path(ctx.out_dir, p.stem + "_filled", ".pdf")
    if not ctx.opts["flatten"]:
        return [_save(w, out)]
    import io

    import pikepdf
    buf = io.BytesIO()
    w.write(buf)
    buf.seek(0)
    pdf = pikepdf.open(buf)
    pdf.generate_appearance_streams()
    pdf.flatten_annotations("all")
    if "/AcroForm" in pdf.Root:
        del pdf.Root["/AcroForm"]
    pdf.save(str(out))
    return [out]
