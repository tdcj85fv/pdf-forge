from __future__ import annotations

import difflib
import io
import re
from datetime import date
from pathlib import Path

import pikepdf

from .registry import Field, ToolError, register
from .util import (anchor_xy, font_name, for_each, hex_color, open_reader, parse_pages, stamp, unique_path)


@register(
    id="protect", name="Protect PDF", category="security", short="PW", inputs="pdf",
    desc="Encrypt a PDF with a password (AES-256) so only people with it can open it.",
    keywords="password encrypt lock secure restrict permissions",
    fields=[
        Field("password", "Password to open", "password", "", required=True),
        Field("owner", "Owner password (optional)", "password", "",
              hint="Needed to change permissions later. Defaults to the open password."),
        Field("allow_print", "Allow printing", "bool", True),
        Field("allow_copy", "Allow copying text", "bool", True),
        Field("allow_edit", "Allow editing", "bool", False),
    ],
)
def protect(ctx):
    o = ctx.opts
    perms = pikepdf.Permissions(
        accessibility=True,
        extract=bool(o["allow_copy"]),
        print_lowres=bool(o["allow_print"]), print_highres=bool(o["allow_print"]),
        modify_other=bool(o["allow_edit"]), modify_annotation=bool(o["allow_edit"]),
        modify_form=bool(o["allow_edit"]), modify_assembly=bool(o["allow_edit"]),
    )
    enc = pikepdf.Encryption(user=o["password"], owner=o["owner"] or o["password"], R=6, allow=perms)

    def one(p):
        try:
            pdf = pikepdf.open(str(p))
        except pikepdf.PasswordError:
            raise ToolError(f"{p.name} is already protected. Unlock it first.")
        out = unique_path(ctx.out_dir, p.stem + "_protected", ".pdf")
        pdf.save(str(out), encryption=enc)
        return out
    return for_each(ctx, one)


@register(
    id="unlock", name="Unlock PDF", category="security", short="UN", inputs="pdf",
    desc="Remove the password and restrictions from a PDF you have the right to open.",
    keywords="decrypt remove password restrictions open permissions",
    fields=[Field("password", "Current password", "password", "",
                  hint="Leave empty if the file opens without one but has editing/printing restrictions.")],
)
def unlock(ctx):
    def one(p):
        try:
            pdf = pikepdf.open(str(p), password=ctx.opts["password"] or "")
        except pikepdf.PasswordError:
            raise ToolError(f"Wrong or missing password for {p.name}.")
        out = unique_path(ctx.out_dir, p.stem + "_unlocked", ".pdf")
        pdf.save(str(out), encryption=False)
        return out
    return for_each(ctx, one)


@register(
    id="sign", name="Sign PDF", category="security", short="SG", inputs="pdf", max_files=1,
    desc="Place your signature (typed or an image of it) on a page, with an optional date.",
    keywords="signature esign sign initials autograph stamp",
    fields=[
        Field("text", "Typed signature", "text", "", hint="Your name. Leave empty if you use an image."),
        Field("image", "Signature image (optional)", "file", "", filt="Images (*.png *.jpg *.jpeg)"),
        Field("page", "Page", "text", "last", hint="A number, first, last, or all"),
        Field("pos", "Position", "choice", "Bottom right", ["Bottom right", "Bottom left", "Bottom center",
                                                           "Top right", "Top left", "Top center"]),
        Field("width", "Width (mm)", "float", 45, minimum=10, maximum=200),
        Field("date", "Add today's date", "bool", True),
    ],
    note="This places a visible signature. It is not a certificate-based digital signature.",
)
def sign(ctx):
    o = ctx.opts
    text = (o["text"] or "").strip()
    if not text and not o["image"]:
        raise ToolError("Type your signature or choose an image of it.")
    mm = 72 / 25.4
    width = float(o["width"]) * mm
    font = font_name()
    img = None
    if o["image"]:
        from PIL import Image
        from reportlab.lib.utils import ImageReader
        pil = Image.open(o["image"]).convert("RGBA")
        img = (ImageReader(pil), pil.width, pil.height)
    stamp_date = date.today().strftime("%d %b %Y") if o["date"] else ""

    def draw(c, W, H):
        height = (width * img[2] / img[1]) if img else width * 0.32
        box_h = height + (12 if stamp_date else 0)
        x, y = anchor_xy(o["pos"], W, H, width, box_h, 36)
        base = y + (12 if stamp_date else 0)
        if img:
            c.drawImage(img[0], x, base, width, height, mask="auto")
        else:
            size = min(height * 0.9, 30)
            c.setFillColor(hex_color("#10206B"))
            # shrink to fit width
            while c.stringWidth(text, "Times-Italic", size) > width and size > 6:
                size -= 1
            c.setFont("Times-Italic", size)
            c.drawString(x, base + height * 0.2, text)
        c.setStrokeColor(hex_color("#555555"))
        c.setLineWidth(0.6)
        c.line(x, base, x + width, base)
        if stamp_date:
            c.setFillColor(hex_color("#555555"))
            c.setFont(font, 8)
            c.drawString(x, y + 1, stamp_date)

    p = ctx.inputs[0]
    from pypdf import PdfWriter
    w = PdfWriter(clone_from=open_reader(p))
    n = len(w.pages)
    which = str(o["page"]).strip().lower()
    targets = list(range(n)) if which == "all" else parse_pages(which or "last", n)[:1]
    for i in targets:
        stamp(w.pages[i], draw)
    out = unique_path(ctx.out_dir, p.stem + "_signed", ".pdf")
    with open(out, "wb") as f:
        w.write(f)
    return [out]


_EMAIL = r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+"
_PHONE = r"(?:\+?\d[\d\s().-]{7,}\d)"
_URL = r"https?://[^\s]+|www\.[^\s]+"


@register(
    id="redact", name="Redact PDF", category="security", short="RD", inputs="pdf", max_files=1,
    desc="Permanently black out sensitive words, emails and phone numbers. Hidden text is truly removed.",
    keywords="blackout censor hide sensitive private remove text confidential",
    fields=[
        Field("terms", "Words or phrases to redact", "multiline", "", hint="One per line."),
        Field("case", "Match case", "bool", False),
        Field("emails", "Redact email addresses", "bool", False),
        Field("phones", "Redact phone numbers", "bool", False),
        Field("urls", "Redact web links", "bool", False),
    ],
    note="Pages with redactions become flattened images so nothing can be recovered; other pages are untouched.",
)
def redact(ctx):
    import pypdfium2 as pdfium
    from PIL import ImageDraw
    from pypdf import PdfReader, PdfWriter

    o = ctx.opts
    terms = [t.strip() for t in str(o["terms"]).splitlines() if t.strip()]
    patterns = []
    if o["emails"]:
        patterns.append(_EMAIL)
    if o["phones"]:
        patterns.append(_PHONE)
    if o["urls"]:
        patterns.append(_URL)
    if not terms and not patterns:
        raise ToolError("Enter at least one word to redact, or tick a pattern.")
    flags = 0 if o["case"] else re.IGNORECASE
    regexes = [re.compile(re.escape(t), flags) for t in terms] + [re.compile(x, flags) for x in patterns]

    p = ctx.inputs[0]
    orig = open_reader(p)
    src = pdfium.PdfDocument(str(p))
    w = PdfWriter()
    scale = 200 / 72
    hits = 0
    for i in range(len(src)):
        page = src[i]
        rot = page.get_rotation()
        if rot:
            page.set_rotation(0)
        tp = page.get_textpage()
        count = tp.count_chars()
        text = tp.get_text_range(0, count) if count else ""
        spans = []
        for rx in regexes:
            spans += [(m.start(), m.end()) for m in rx.finditer(text) if m.end() > m.start()]
        if not spans:
            w.add_page(orig.pages[i])
            continue
        l, b, r, t = page.get_cropbox()
        pil = page.render(scale=scale).to_pil().convert("RGB")
        d = ImageDraw.Draw(pil)
        for s, e in spans:
            for ci in range(s, min(e, count)):
                cl, cb, cr, ct = tp.get_charbox(ci)
                if cr - cl <= 0:
                    continue
                d.rectangle([(cl - l - 1) * scale, (t - ct - 1) * scale, (cr - l + 1) * scale, (t - cb + 1) * scale],
                            fill="black")
            hits += 1
        buf = io.BytesIO()
        pil.save(buf, "PDF", resolution=200)
        newpage = PdfReader(buf).pages[0]
        newpage.scale_to(r - l, t - b)
        if rot:
            newpage.rotate(rot)
        w.add_page(newpage)
        ctx.progress((i + 1) / len(src))
    if not hits:
        raise ToolError("Nothing matched, so no file was written.")
    out = unique_path(ctx.out_dir, p.stem + "_redacted", ".pdf")
    with open(out, "wb") as f:
        w.write(f)
    ctx.log(f"Redacted {hits} match(es).")
    return [out]


@register(
    id="compare", name="Compare PDF", category="security", short="CMP", inputs="pdf",
    min_files=2, max_files=2,
    desc="Spot the differences between two versions of a document, side by side.",
    keywords="difference diff versions changes side by side review",
)
def compare(ctx):
    import pdfplumber

    def lines(path):
        out = []
        with pdfplumber.open(str(path)) as pdf:
            for i, pg in enumerate(pdf.pages):
                for ln in (pg.extract_text() or "").splitlines():
                    out.append(ln.strip())
                out.append(f"----- end of page {i + 1} -----")
        return out
    a, b = ctx.inputs
    la, lb = lines(a), lines(b)
    ctx.progress(0.6)
    diff = difflib.HtmlDiff(wrapcolumn=70)
    html = diff.make_file(la, lb, a.name, b.name, context=True, numlines=2)
    html = html.replace("</head>", "<style>body{font-family:Segoe UI,Arial,sans-serif;background:#fff}"
                        "table.diff{font-family:Consolas,monospace;font-size:12px}</style></head>")
    out = unique_path(ctx.out_dir, f"compare_{a.stem}_vs_{b.stem}", ".html")
    out.write_text(html, encoding="utf-8")
    changed = sum(1 for x in difflib.ndiff(la, lb) if x[:2] in ("+ ", "- "))
    ctx.log("The two documents have identical text." if changed == 0 else f"{changed} changed line(s). Report saved.")
    return [out]
