; PDFForge installer (Inno Setup 6).  Build with:  iscc installer\pdfforge.iss
; The LAST page of the wizard, shown after the files are installed and before "Finish", is the donation screen.

#define MyAppName "PDFForge"
#define MyAppVersion "0.1.0"
#define MyAppPublisher "PDFForge"
#define MyAppExe "PDFForge.exe"
; Change this to your own donation link (Ko-fi, Buy Me a Coffee, PayPal.me, UPI page, GitHub Sponsors...)
#define DonateUrl "https://example.com/donate"

[Setup]
AppId={{7B1C2E64-5B7A-4D34-9E0B-3C1D5A9F2B11}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
OutputDir=..\dist_installer
OutputBaseFilename=PDFForge-Setup-{#MyAppVersion}
SetupIconFile=..\assets\icon.ico
UninstallDisplayIcon={app}\{#MyAppExe}
WizardStyle=modern
WizardImageFile=wizard_big.bmp,wizard_big_2x.bmp
WizardSmallImageFile=wizard_small.bmp,wizard_small_2x.bmp
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "..\dist\PDFForge\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion
; Optional helper programs. Drop portable Tesseract / Ghostscript into third_party\ before building to bundle them.
Source: "..\third_party\*"; DestDir: "{app}\third_party"; Flags: recursesubdirs createallsubdirs skipifsourcedoesntexist

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExe}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent

[Code]
var
  DonatePage: TWizardPage;

procedure DonateClick(Sender: TObject);
var
  ErrorCode: Integer;
begin
  ShellExec('open', '{#DonateUrl}', '', '', SW_SHOWNORMAL, ewNoWait, ErrorCode);
end;

procedure InitializeWizard;
var
  Banner: TPanel;
  Heart, Msg: TNewStaticText;
  Btn: TNewButton;
begin
  { Inserted after the "Installing" page, so it is the final screen before Finish. }
  DonatePage := CreateCustomPage(wpInstalling, 'Support {#MyAppName}',
    'Free, offline and ad-free, kept alive by people like you.');

  Banner := TPanel.Create(DonatePage);
  Banner.Parent := DonatePage.Surface;
  Banner.Left := 0;
  Banner.Top := 0;
  Banner.Width := DonatePage.SurfaceWidth;
  Banner.Height := ScaleY(150);
  Banner.BevelOuter := bvNone;
  Banner.ParentBackground := False;
  Banner.Color := $0D0B0B;   { black (BGR) }

  Heart := TNewStaticText.Create(DonatePage);
  Heart.Parent := Banner;
  Heart.Caption := 'Thank you for installing {#MyAppName}!';
  Heart.Font.Size := 15;
  Heart.Font.Style := [fsBold];
  Heart.Font.Color := $5530FF;  { pinkish red #FF3055 (BGR) }
  Heart.Left := ScaleX(20);
  Heart.Top := ScaleY(18);
  Heart.Transparent := True;

  Msg := TNewStaticText.Create(DonatePage);
  Msg.Parent := Banner;
  Msg.AutoSize := False;
  Msg.WordWrap := True;
  Msg.Left := ScaleX(20);
  Msg.Top := ScaleY(56);
  Msg.Width := Banner.Width - ScaleX(40);
  Msg.Height := ScaleY(80);
  Msg.Font.Color := clWhite;
  Msg.Transparent := True;
  Msg.Caption :=
    '{#MyAppName} is free and works fully on your computer: no uploads, no ads, no limits.' + #13#10 + #13#10 +
    'If it saves you time, a small donation helps keep it free and growing.';

  Btn := TNewButton.Create(DonatePage);
  Btn.Parent := DonatePage.Surface;
  Btn.Caption := 'Donate';
  Btn.Left := 0;
  Btn.Top := Banner.Height + ScaleY(18);
  Btn.Width := ScaleX(150);
  Btn.Height := ScaleY(34);
  Btn.OnClick := @DonateClick;

  Msg := TNewStaticText.Create(DonatePage);
  Msg.Parent := DonatePage.Surface;
  Msg.AutoSize := False;
  Msg.WordWrap := True;
  Msg.Left := Btn.Width + ScaleX(14);
  Msg.Top := Btn.Top + ScaleY(8);
  Msg.Width := DonatePage.SurfaceWidth - Btn.Width - ScaleX(14);
  Msg.Height := ScaleY(40);
  Msg.Caption := 'Opens your web browser. Donating is optional. Click Next to finish the installation.';
end;
