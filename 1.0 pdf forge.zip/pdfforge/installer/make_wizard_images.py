"""Creates the pink-red/black banner images used by the installer. Run: python installer/make_wizard_images.py"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

OUT = Path(__file__).resolve().parent
ICON = Image.open(OUT.parent / "assets" / "icon.png").convert("RGBA")


def font(size):
    for p in ("C:/Windows/Fonts/segoeuib.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(p, size)
        except OSError:
            pass
    return ImageFont.load_default()


def big(w, h, path):
    im = Image.new("RGB", (w, h), (11, 11, 13))
    d = ImageDraw.Draw(im)
    for y in range(h):  # soft pink-red glow rising from the bottom
        t = max(0, (y - h * 0.45) / (h * 0.55))
        d.line([(0, y), (w, y)], fill=(int(11 + 120 * t * t), int(11 + 10 * t * t), int(13 + 30 * t * t)))
    icon = ICON.resize((int(w * 0.62),) * 2)
    im.paste(icon, ((w - icon.width) // 2, int(h * 0.12)), icon)
    d.text((w / 2, h * 0.52), "PDFForge", font=font(int(w * 0.15)), fill=(255, 255, 255), anchor="mm")
    d.text((w / 2, h * 0.58), "offline PDF tools", font=font(int(w * 0.085)), fill=(255, 92, 124), anchor="mm")
    im.save(path)


def small(s, path):
    im = Image.new("RGB", (s, s), (11, 11, 13))
    icon = ICON.resize((int(s * 0.86),) * 2)
    im.paste(icon, ((s - icon.width) // 2,) * 2, icon)
    im.save(path)


big(164, 314, OUT / "wizard_big.bmp")
big(328, 628, OUT / "wizard_big_2x.bmp")
small(55, OUT / "wizard_small.bmp")
small(110, OUT / "wizard_small_2x.bmp")
print("wizard images written")
