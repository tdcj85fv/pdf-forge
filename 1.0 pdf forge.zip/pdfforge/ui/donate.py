from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QDialog, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

import app_config as C
from .theme import logo_pixmap


class DonateDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Support {C.APP_NAME}")
        self.setMinimumWidth(440)
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 26, 28, 22)
        v.setSpacing(14)
        logo = QLabel()
        logo.setPixmap(logo_pixmap(56))
        logo.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        title = QLabel("Keep it free ♥")
        title.setObjectName("h1")
        title.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        msg = QLabel(C.DONATE_MESSAGE)
        msg.setWordWrap(True)
        msg.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        msg.setObjectName("muted")
        row = QHBoxLayout()
        later = QPushButton("Maybe later")
        later.clicked.connect(self.accept)
        donate = QPushButton("♥  Donate")
        donate.setObjectName("primary")
        donate.setCursor(Qt.CursorShape.PointingHandCursor)
        donate.clicked.connect(self._open)
        row.addStretch(1)
        row.addWidget(later)
        row.addWidget(donate)
        row.addStretch(1)
        for w in (logo, title, msg):
            v.addWidget(w)
        v.addLayout(row)

    def _open(self):
        QDesktopServices.openUrl(QUrl(C.DONATE_URL))
        self.accept()
