from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QKeySequence, QShortcut
from PySide6.QtWidgets import (QFrame, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
                               QStackedWidget, QVBoxLayout, QWidget)

import app_config as C
from core import TOOLS, search
from .donate import DonateDialog
from .home_page import HomePage
from .theme import logo_pixmap
from .tool_page import ToolPage


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{C.APP_NAME}  -  {C.APP_TAGLINE}")
        icon = C.resource_path("assets/icon.ico")
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))
        self.resize(1180, 780)
        self.setMinimumSize(900, 620)

        root = QWidget()
        root.setObjectName("root")
        self.setCentralWidget(root)
        v = QVBoxLayout(root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        # header: logo, search, donate
        header = QFrame()
        header.setObjectName("header")
        h = QHBoxLayout(header)
        h.setContentsMargins(22, 12, 22, 12)
        h.setSpacing(14)
        logo = QLabel()
        logo.setPixmap(logo_pixmap(38))
        names = QVBoxLayout()
        names.setSpacing(0)
        brand = QLabel(C.APP_NAME)
        brand.setObjectName("brand")
        tag = QLabel("Offline  ·  No uploads  ·  Free")
        tag.setObjectName("tagline")
        names.addWidget(brand)
        names.addWidget(tag)
        brand_box = QWidget()
        brand_box.setLayout(names)
        brand_box.setCursor(Qt.CursorShape.PointingHandCursor)
        brand_box.mousePressEvent = lambda e: self.go_home(clear=True)
        logo.setCursor(Qt.CursorShape.PointingHandCursor)
        logo.mousePressEvent = lambda e: self.go_home(clear=True)

        self.search = QLineEdit()
        self.search.setObjectName("search")
        self.search.setPlaceholderText("Search tools…   (Ctrl+K)")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self._on_search)
        self.search.returnPressed.connect(self._open_first)

        donate = QPushButton("♥  Donate")
        donate.setObjectName("donate")
        donate.setCursor(Qt.CursorShape.PointingHandCursor)
        donate.clicked.connect(lambda: DonateDialog(self).exec())

        h.addWidget(logo)
        h.addWidget(brand_box)
        h.addStretch(1)
        h.addWidget(self.search)
        h.addStretch(1)
        h.addWidget(donate)
        v.addWidget(header)

        self.stack = QStackedWidget()
        self.home = HomePage()
        self.page = ToolPage()
        self.stack.addWidget(self.home)
        self.stack.addWidget(self.page)
        v.addWidget(self.stack, 1)

        self.home.toolRequested.connect(self.open_tool)
        self.page.back.connect(lambda: self.go_home())

        QShortcut(QKeySequence("Ctrl+K"), self, activated=self._focus_search)
        QShortcut(QKeySequence("Ctrl+F"), self, activated=self._focus_search)
        QShortcut(QKeySequence("Esc"), self, activated=self._escape)

    # ---------------------------------------------------------- navigation
    def open_tool(self, tool_id: str):
        tool = TOOLS[tool_id]
        if not tool.available:
            QMessageBox.information(self, tool.name, f"{tool.name} is coming in a later update.\n\n{tool.note}")
            return
        self.page.load(tool)
        self.stack.setCurrentWidget(self.page)

    def go_home(self, clear: bool = False):
        if clear and self.search.text():
            self.search.clear()  # triggers _on_search
        self.stack.setCurrentWidget(self.home)

    # ---------------------------------------------------------- search
    def _on_search(self, text: str):
        text = text.strip()
        if self.page.thread is not None:   # a tool is running; keep the page
            return
        if text:
            self.home.show_results(text, search(text))
        else:
            self.home.show_all()
        self.stack.setCurrentWidget(self.home)

    def _open_first(self):
        tool = self.home.first_result() if self.search.text().strip() else None
        if tool:
            self.open_tool(tool.id)

    def _focus_search(self):
        self.search.setFocus()
        self.search.selectAll()

    def _escape(self):
        if self.search.hasFocus() and self.search.text():
            self.search.clear()
        elif self.stack.currentWidget() is self.page and self.page.thread is None:
            self.go_home()
