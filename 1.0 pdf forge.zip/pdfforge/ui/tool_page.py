"""The page shown when a tool is open: files on the left, options on the right, run at the bottom."""
from __future__ import annotations

import subprocess
import sys
import traceback
from pathlib import Path

from PySide6.QtCore import QObject, QSettings, Qt, QThread, QUrl, Signal, Slot
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (QCheckBox, QFileDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPlainTextEdit, QProgressBar, QPushButton, QScrollArea, QVBoxLayout, QWidget)

import app_config as C
from core import Tool, ToolError, execute
from core.registry import INPUT_LABELS
from .widgets import FileList, OptionForm


class Worker(QObject):
    log = Signal(str)
    progress = Signal(float)
    done = Signal(list)
    failed = Signal(str)

    def __init__(self, tool, inputs, opts, out_dir):
        super().__init__()
        self.tool, self.inputs, self.opts, self.out_dir = tool, inputs, opts, out_dir
        self._cancel = False

    def cancel(self):
        self._cancel = True

    @Slot()
    def run(self):
        try:
            outs = execute(self.tool, self.inputs, self.opts, self.out_dir,
                           log=self.log.emit, progress=self.progress.emit, cancelled=lambda: self._cancel)
            self.done.emit([str(o) for o in outs])
        except ToolError as e:
            self.failed.emit(str(e))
        except Exception as e:  # noqa: BLE001 - never crash the window
            try:
                logdir = Path.home() / ".pdfforge"
                logdir.mkdir(exist_ok=True)
                (logdir / "error.log").write_text(traceback.format_exc(), encoding="utf-8")
            except OSError:
                pass
            self.failed.emit(f"Something unexpected went wrong: {e}\n(Details saved to ~/.pdfforge/error.log)")


def reveal(path: str):
    """Open the folder and, on Windows, highlight the file."""
    p = Path(path)
    if sys.platform == "win32" and p.exists():
        subprocess.Popen(["explorer", "/select,", str(p)])
    else:
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(p.parent)))


class ToolPage(QWidget):
    back = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.tool: Tool | None = None
        self.thread: QThread | None = None
        self.worker: Worker | None = None
        self.outputs: list[str] = []
        self.settings = QSettings(C.APP_NAME, C.APP_NAME)

        root = QVBoxLayout(self)
        root.setContentsMargins(28, 18, 28, 18)
        root.setSpacing(12)

        top = QHBoxLayout()
        self.back_btn = QPushButton("←  All tools")
        self.back_btn.setObjectName("ghost")
        self.back_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.back_btn.clicked.connect(self.back.emit)
        top.addWidget(self.back_btn)
        top.addStretch(1)
        root.addLayout(top)

        self.title = QLabel()
        self.title.setObjectName("h1")
        self.desc = QLabel()
        self.desc.setObjectName("muted")
        self.desc.setWordWrap(True)
        self.note = QLabel()
        self.note.setObjectName("note")
        self.note.setWordWrap(True)
        root.addWidget(self.title)
        root.addWidget(self.desc)
        root.addWidget(self.note)

        body = QHBoxLayout()
        body.setSpacing(22)
        # left: files
        left = QVBoxLayout()
        self.files = FileList()
        self.files.changed.connect(self._refresh_state)
        left.addWidget(self.files, 1)
        row = QHBoxLayout()
        self.add_btn = QPushButton("＋  Add files")
        self.add_btn.clicked.connect(self._add_files)
        self.remove_btn = QPushButton("Remove")
        self.remove_btn.clicked.connect(self.files.remove_selected)
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.clicked.connect(self.files.clear_all)
        self.up_btn = QPushButton("▲")
        self.up_btn.setToolTip("Move up")
        self.up_btn.clicked.connect(lambda: self.files.move_selected(-1))
        self.down_btn = QPushButton("▼")
        self.down_btn.setToolTip("Move down")
        self.down_btn.clicked.connect(lambda: self.files.move_selected(1))
        for b in (self.add_btn, self.remove_btn, self.clear_btn, self.up_btn, self.down_btn):
            row.addWidget(b)
        row.addStretch(1)
        left.addLayout(row)
        body.addLayout(left, 5)

        # right: options
        right_frame = QFrame()
        right_frame.setStyleSheet(f"QFrame#opts {{ background: {C.PANEL}; border: 1px solid {C.BORDER}; "
                                  f"border-radius: 14px; }}")
        right_frame.setObjectName("opts")
        rl = QVBoxLayout(right_frame)
        rl.setContentsMargins(18, 16, 18, 16)
        heading = QLabel("Options")
        heading.setObjectName("h2")
        rl.addWidget(heading)
        self.form = OptionForm()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.form)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        rl.addWidget(scroll, 1)
        self.no_opts = QLabel("This tool has no options. Just add your files and press the button.")
        self.no_opts.setObjectName("muted")
        self.no_opts.setWordWrap(True)
        rl.addWidget(self.no_opts)
        body.addWidget(right_frame, 4)
        root.addLayout(body, 1)

        # output location
        out_row = QHBoxLayout()
        self.same_folder = QCheckBox("Save next to the original file")
        self.same_folder.setChecked(self.settings.value("same_folder", True, type=bool))
        self.same_folder.toggled.connect(self._out_toggled)
        self.out_edit = QLineEdit(self.settings.value("out_dir", str(Path.home() / "Documents")))
        self.out_pick = QPushButton("Choose folder…")
        self.out_pick.clicked.connect(self._pick_out)
        out_row.addWidget(self.same_folder)
        out_row.addWidget(self.out_edit, 1)
        out_row.addWidget(self.out_pick)
        root.addLayout(out_row)
        self._out_toggled(self.same_folder.isChecked())

        # run
        run_row = QHBoxLayout()
        self.run_btn = QPushButton("Run")
        self.run_btn.setObjectName("primary")
        self.run_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.run_btn.clicked.connect(self._run)
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.clicked.connect(self._cancel)
        self.cancel_btn.hide()
        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(10)
        run_row.addWidget(self.run_btn)
        run_row.addWidget(self.cancel_btn)
        run_row.addWidget(self.bar, 1)
        root.addLayout(run_row)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        root.addWidget(self.status)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(110)
        self.log.hide()
        root.addWidget(self.log)
        res = QHBoxLayout()
        self.reveal_btn = QPushButton("Show in folder")
        self.reveal_btn.clicked.connect(lambda: self.outputs and reveal(self.outputs[0]))
        self.open_btn = QPushButton("Open file")
        self.open_btn.clicked.connect(lambda: self.outputs and QDesktopServices.openUrl(
            QUrl.fromLocalFile(self.outputs[0])))
        res.addWidget(self.reveal_btn)
        res.addWidget(self.open_btn)
        res.addStretch(1)
        self.result_row = QWidget()
        self.result_row.setLayout(res)
        self.result_row.hide()
        root.addWidget(self.result_row)

    # ------------------------------------------------------------ loading
    def load(self, tool: Tool):
        self.tool = tool
        self.title.setText(tool.name)
        self.desc.setText(tool.desc)
        self.note.setText(tool.note)
        self.note.setVisible(bool(tool.note))
        label = INPUT_LABELS.get(tool.inputs, "Files")
        multi = tool.max_files != 1
        self.files.clear_all()
        self.files.configure(tool.extensions, not multi,
                             f"Drop {label.lower()} here, or click “Add files”")
        self.add_btn.setText("＋  Add files" if multi else "＋  Choose file")
        self.up_btn.setVisible(tool.reorder)
        self.down_btn.setVisible(tool.reorder)
        self.remove_btn.setVisible(multi)
        self.clear_btn.setVisible(multi)
        self.form.build(tool.fields)
        self.no_opts.setVisible(not tool.fields)
        self.run_btn.setText(f"{tool.name}")
        self.status.clear()
        self.log.clear()
        self.log.hide()
        self.result_row.hide()
        self.bar.setValue(0)
        self._refresh_state()

    def _refresh_state(self):
        if not self.tool:
            return
        n = self.files.count()
        ok = n >= self.tool.min_files and self.thread is None
        self.run_btn.setEnabled(ok)
        if n < self.tool.min_files and self.thread is None:
            need = self.tool.min_files
            self.status.setObjectName("muted")
            self.status.setStyleSheet(f"color: {C.MUTED};")
            self.status.setText(f"Add {need - n} more file(s) to continue." if n else "")

    # ------------------------------------------------------------ actions
    def _add_files(self):
        t = self.tool
        exts = " ".join("*" + e for e in t.extensions) if t.extensions else "*"
        label = INPUT_LABELS.get(t.inputs, "Files")
        multi = t.max_files != 1
        start = self.settings.value("last_dir", "")
        if multi:
            paths, _ = QFileDialog.getOpenFileNames(self, "Add files", start, f"{label} ({exts});;All files (*)")
        else:
            p, _ = QFileDialog.getOpenFileName(self, "Choose file", start, f"{label} ({exts});;All files (*)")
            paths = [p] if p else []
        if paths:
            self.settings.setValue("last_dir", str(Path(paths[0]).parent))
            self.files.add_paths(paths)

    def _out_toggled(self, same: bool):
        self.out_edit.setEnabled(not same)
        self.out_pick.setEnabled(not same)
        self.settings.setValue("same_folder", same)

    def _pick_out(self):
        d = QFileDialog.getExistingDirectory(self, "Choose output folder", self.out_edit.text())
        if d:
            self.out_edit.setText(d)
            self.settings.setValue("out_dir", d)

    def _out_dir(self) -> Path:
        if self.same_folder.isChecked():
            return self.files.paths()[0].parent
        return Path(self.out_edit.text() or Path.home() / "Documents")

    def _run(self):
        if not self.tool or self.thread:
            return
        self.status.setText("")
        self.log.clear()
        self.log.show()
        self.result_row.hide()
        self.bar.setValue(0)
        self.worker = Worker(self.tool, self.files.paths(), self.form.values(), self._out_dir())
        self.thread = QThread(self)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.log.connect(self.log.appendPlainText)
        self.worker.progress.connect(lambda f: self.bar.setValue(int(f * 100)))
        self.worker.done.connect(self._on_done)
        self.worker.failed.connect(self._on_failed)
        self.worker.done.connect(self.thread.quit)
        self.worker.failed.connect(self.thread.quit)
        self.thread.finished.connect(self._on_finished)
        self._set_busy(True)
        self.thread.start()

    def _cancel(self):
        if self.worker:
            self.worker.cancel()
            self.cancel_btn.setEnabled(False)

    def _set_busy(self, busy: bool):
        self.run_btn.setEnabled(not busy)
        self.cancel_btn.setVisible(busy)
        self.cancel_btn.setEnabled(busy)
        self.add_btn.setEnabled(not busy)
        self.back_btn.setEnabled(not busy)

    def _on_done(self, outs: list):
        self.outputs = outs
        self.bar.setValue(100)
        n = len(outs)
        self.status.setStyleSheet(f"color: {C.OK}; font-weight: 600;")
        self.status.setText(f"Done. {n} file(s) created in {Path(outs[0]).parent}" if outs else "Done.")
        self.result_row.setVisible(bool(outs))
        self.open_btn.setVisible(n == 1)

    def _on_failed(self, msg: str):
        self.bar.setValue(0)
        self.status.setStyleSheet(f"color: {C.ERROR}; font-weight: 600;")
        self.status.setText(msg)

    def _on_finished(self):
        if self.thread:
            self.thread.deleteLater()
        if self.worker:
            self.worker.deleteLater()
        self.thread = None
        self.worker = None
        self._set_busy(False)
        self._refresh_state()
