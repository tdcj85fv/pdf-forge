"""Pinkish-red and black theme: one stylesheet plus a few painted icons."""
from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap

import app_config as C


def stylesheet() -> str:
    return f"""
* {{ font-family: "Segoe UI", "Inter", "Noto Sans", Arial, sans-serif; font-size: 13px; color: {C.TEXT}; }}
QMainWindow, QDialog, QWidget#root {{ background: {C.BG}; }}
QWidget {{ background: transparent; }}
QToolTip {{ background: {C.CARD}; color: {C.TEXT}; border: 1px solid {C.ACCENT}; padding: 4px 6px; }}

QFrame#header {{ background: {C.PANEL}; border-bottom: 1px solid {C.BORDER}; }}
QLabel#brand {{ font-size: 18px; font-weight: 700; }}
QLabel#tagline {{ color: {C.MUTED}; font-size: 12px; }}
QLabel#h1 {{ font-size: 24px; font-weight: 700; }}
QLabel#h2 {{ font-size: 15px; font-weight: 700; color: {C.ACCENT}; }}
QLabel#muted, QLabel#hint {{ color: {C.MUTED}; font-size: 12px; }}
QLabel#note {{ color: {C.ACCENT_HOVER}; font-size: 12px; }}
QLabel#error {{ color: {C.ERROR}; }}
QLabel#ok {{ color: {C.OK}; }}

QLineEdit, QPlainTextEdit, QTextEdit, QSpinBox, QDoubleSpinBox, QComboBox {{
    background: {C.CARD}; border: 1px solid {C.BORDER}; border-radius: 8px; padding: 7px 10px;
    selection-background-color: {C.ACCENT}; selection-color: white;
}}
QLineEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus {{
    border: 1px solid {C.ACCENT};
}}
QLineEdit#search {{
    background: {C.BG}; border: 1px solid {C.BORDER}; border-radius: 18px; padding: 8px 16px; min-width: 340px;
}}
QLineEdit#search:focus {{ border: 1px solid {C.ACCENT}; background: #101013; }}
QLineEdit:disabled {{ color: {C.MUTED}; }}
QComboBox::drop-down {{ border: none; width: 24px; }}
QComboBox QAbstractItemView {{
    background: {C.CARD}; border: 1px solid {C.ACCENT}; selection-background-color: {C.ACCENT};
    outline: none;
}}
QSpinBox::up-button, QSpinBox::down-button, QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
    width: 16px; border: none; background: transparent;
}}

QPushButton {{
    background: {C.CARD}; border: 1px solid {C.BORDER}; border-radius: 8px; padding: 8px 16px;
}}
QPushButton:hover {{ background: {C.CARD_HOVER}; border-color: {C.ACCENT}; }}
QPushButton:disabled {{ color: {C.MUTED}; border-color: {C.BORDER}; background: {C.PANEL}; }}
QPushButton#primary {{
    background: {C.ACCENT}; border: none; color: white; font-weight: 700; font-size: 14px; padding: 11px 30px;
}}
QPushButton#primary:hover {{ background: {C.ACCENT_HOVER}; }}
QPushButton#primary:pressed {{ background: {C.ACCENT_PRESSED}; }}
QPushButton#primary:disabled {{ background: #3A2A30; color: #8A6A74; }}
QPushButton#ghost {{ background: transparent; border: none; color: {C.MUTED}; }}
QPushButton#ghost:hover {{ color: {C.ACCENT_HOVER}; }}
QPushButton#donate {{
    background: {C.ACCENT_SOFT}; border: 1px solid {C.ACCENT}; color: {C.ACCENT_HOVER}; border-radius: 16px;
    padding: 7px 16px; font-weight: 600;
}}
QPushButton#donate:hover {{ background: {C.ACCENT}; color: white; }}

QPushButton#card {{
    background: {C.CARD}; border: 1px solid {C.BORDER}; border-radius: 14px; text-align: left; padding: 0;
}}
QPushButton#card:hover {{ background: {C.CARD_HOVER}; border: 1px solid {C.ACCENT}; }}
QPushButton#card:focus {{ border: 1px solid {C.ACCENT_HOVER}; }}
QPushButton#card[planned="true"] {{ background: {C.PANEL}; border: 1px dashed {C.BORDER}; }}
QLabel#cardTitle {{ font-weight: 700; font-size: 14px; }}
QLabel#cardDesc {{ color: {C.MUTED}; font-size: 12px; }}
QLabel#soon {{
    background: {C.ACCENT_SOFT}; color: {C.ACCENT_HOVER}; border-radius: 8px; padding: 1px 8px; font-size: 10px;
    font-weight: 700;
}}

QListWidget {{
    background: {C.PANEL}; border: 2px dashed {C.BORDER}; border-radius: 12px; padding: 6px; outline: none;
}}
QListWidget::item {{ background: {C.CARD}; border-radius: 8px; padding: 9px 10px; margin: 3px 2px; }}
QListWidget::item:selected {{ background: {C.ACCENT_SOFT}; border: 1px solid {C.ACCENT}; color: white; }}

QCheckBox {{ spacing: 9px; }}
QCheckBox::indicator {{ width: 18px; height: 18px; border-radius: 5px; border: 1px solid {C.BORDER}; background: {C.CARD}; }}
QCheckBox::indicator:hover {{ border-color: {C.ACCENT}; }}
QCheckBox::indicator:checked {{ background: {C.ACCENT}; border-color: {C.ACCENT}; }}

QProgressBar {{ background: {C.CARD}; border: none; border-radius: 5px; height: 10px; text-align: center; color: transparent; }}
QProgressBar::chunk {{ background: {C.ACCENT}; border-radius: 5px; }}

QScrollArea {{ border: none; background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 12px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {C.BORDER}; border-radius: 5px; min-height: 40px; }}
QScrollBar::handle:vertical:hover {{ background: {C.ACCENT}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; width: 0; }}
QScrollBar:horizontal {{ height: 0; }}
QMessageBox {{ background: {C.PANEL}; }}
"""


def apply_theme(app):
    app.setStyle("Fusion")
    app.setStyleSheet(stylesheet())


def badge_pixmap(text: str, size: int = 46, muted: bool = False) -> QPixmap:
    """Rounded pink-red tile with a short label, used as each tool's icon."""
    dpr = 2
    pm = QPixmap(size * dpr, size * dpr)
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    g = QLinearGradient(0, 0, size, size)
    if muted:
        g.setColorAt(0, QColor("#3A3A44"))
        g.setColorAt(1, QColor("#26262D"))
    else:
        g.setColorAt(0, QColor("#FF5C7C"))
        g.setColorAt(1, QColor("#D91F45"))
    p.setBrush(QBrush(g))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(QRectF(0, 0, size, size), 12, 12)
    f = QFont("Segoe UI")
    f.setBold(True)
    f.setPixelSize(int(size * (0.30 if len(text) > 2 else 0.36)))
    p.setFont(f)
    p.setPen(QColor("white" if not muted else "#9B9BA7"))
    p.drawText(QRectF(0, 0, size, size), Qt.AlignmentFlag.AlignCenter, text)
    p.end()
    return pm


def logo_pixmap(size: int = 36) -> QPixmap:
    """A page with a folded corner in pink-red on black."""
    dpr = 2
    pm = QPixmap(size * dpr, size * dpr)
    pm.setDevicePixelRatio(dpr)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setBrush(QColor("#000000"))
    p.setPen(QPen(QColor(C.ACCENT), 1.5))
    p.drawRoundedRect(QRectF(1, 1, size - 2, size - 2), 9, 9)
    s = size
    page = QPainterPath()
    page.moveTo(s * 0.30, s * 0.18)
    page.lineTo(s * 0.58, s * 0.18)
    page.lineTo(s * 0.72, s * 0.32)
    page.lineTo(s * 0.72, s * 0.82)
    page.lineTo(s * 0.30, s * 0.82)
    page.closeSubpath()
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(C.ACCENT))
    p.drawPath(page)
    fold = QPainterPath()
    fold.moveTo(s * 0.58, s * 0.18)
    fold.lineTo(s * 0.58, s * 0.32)
    fold.lineTo(s * 0.72, s * 0.32)
    fold.closeSubpath()
    p.setBrush(QColor("#FFB3C1"))
    p.drawPath(fold)
    p.setPen(QColor("white"))
    f = QFont("Segoe UI")
    f.setBold(True)
    f.setPixelSize(int(s * 0.17))
    p.setFont(f)
    p.drawText(QRectF(s * 0.30, s * 0.46, s * 0.42, s * 0.3), Qt.AlignmentFlag.AlignCenter, "PDF")
    p.end()
    return pm
