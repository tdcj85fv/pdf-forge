"""Reusable widgets: tool card, drop-in file list, auto-generated option form."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog, QFormLayout, QHBoxLayout,
                               QLabel, QLineEdit, QListWidget, QListWidgetItem, QPlainTextEdit, QPushButton,
                               QSizePolicy, QSpinBox, QVBoxLayout, QWidget, QAbstractItemView)

import app_config as C
from core import Field, Tool
from core.registry import CATEGORY_NAMES
from .theme import badge_pixmap


class ToolCard(QPushButton):
    """A clickable card for one tool on the home screen."""

    def __init__(self, tool: Tool, parent=None):
        super().__init__(parent)
        self.tool = tool
        self.setObjectName("card")
        self.setProperty("planned", not tool.available)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(104)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.setToolTip(tool.desc if tool.available else f"{tool.desc}\n\n{tool.note}")

        lay = QHBoxLayout(self)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(12)
        icon = QLabel()
        icon.setPixmap(badge_pixmap(tool.short, 46, muted=not tool.available))
        icon.setFixedSize(46, 46)
        icon.setAlignment(Qt.AlignmentFlag.AlignTop)
        col = QVBoxLayout()
        col.setSpacing(3)
        title_row = QHBoxLayout()
        title = QLabel(tool.name)
        title.setObjectName("cardTitle")
        title_row.addWidget(title)
        if not tool.available:
            soon = QLabel("SOON")
            soon.setObjectName("soon")
            title_row.addWidget(soon)
        title_row.addStretch(1)
        desc = QLabel(tool.desc)
        desc.setObjectName("cardDesc")
        desc.setWordWrap(True)
        desc.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        col.addLayout(title_row)
        col.addWidget(desc, 1)
        lay.addWidget(icon, 0, Qt.AlignmentFlag.AlignTop)
        lay.addLayout(col, 1)
        for w in (icon, title, desc):
            w.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)


class FileList(QListWidget):
    """Shows chosen files. Accepts drag and drop from Explorer."""

    changed = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.setDragDropMode(QAbstractItemView.DragDropMode.NoDragDrop)
        self.setMinimumHeight(220)
        self._exts: list[str] = []
        self._single = False
        self._hint = "Drop files here, or click “Add files”"

    def configure(self, exts: list[str], single: bool, hint: str):
        self._exts, self._single, self._hint = exts, single, hint
        self.viewport().update()

    # -- data
    def paths(self) -> list[Path]:
        return [Path(self.item(i).data(Qt.ItemDataRole.UserRole)) for i in range(self.count())]

    def add_paths(self, paths):
        have = {str(p) for p in self.paths()}
        for p in paths:
            p = Path(p)
            if str(p) in have or not p.is_file():
                continue
            if self._exts and p.suffix.lower() not in self._exts:
                continue
            if self._single:
                self.clear()
                have.clear()
            item = QListWidgetItem(f"{p.name}\n{p.parent}")
            item.setData(Qt.ItemDataRole.UserRole, str(p))
            item.setToolTip(str(p))
            self.addItem(item)
            have.add(str(p))
        self.changed.emit()

    def remove_selected(self):
        for it in self.selectedItems():
            self.takeItem(self.row(it))
        self.changed.emit()

    def clear_all(self):
        self.clear()
        self.changed.emit()

    def move_selected(self, delta: int):
        rows = sorted({self.row(i) for i in self.selectedItems()}, reverse=(delta > 0))
        for r in rows:
            nr = r + delta
            if 0 <= nr < self.count():
                it = self.takeItem(r)
                self.insertItem(nr, it)
                it.setSelected(True)
        self.changed.emit()

    # -- drag and drop from the desktop
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        self.add_paths(paths)
        e.acceptProposedAction()

    def paintEvent(self, e):
        super().paintEvent(e)
        if self.count() == 0:
            p = QPainter(self.viewport())
            p.setPen(QColor(C.MUTED))
            p.drawText(self.viewport().rect(), Qt.AlignmentFlag.AlignCenter, self._hint)
            p.end()


class OptionForm(QWidget):
    """Builds input widgets from a tool's Field declarations."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._lay = QFormLayout(self)
        self._lay.setContentsMargins(0, 0, 0, 0)
        self._lay.setVerticalSpacing(12)
        self._lay.setLabelAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignTop)
        self._lay.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        self._getters: dict = {}

    def build(self, fields: list[Field]):
        while self._lay.rowCount():
            self._lay.removeRow(0)
        self._getters.clear()
        for f in fields:
            w, getter = self._make(f)
            self._getters[f.key] = getter
            box = QWidget()
            v = QVBoxLayout(box)
            v.setContentsMargins(0, 0, 0, 0)
            v.setSpacing(3)
            v.addWidget(w)
            if f.hint:
                h = QLabel(f.hint)
                h.setObjectName("hint")
                h.setWordWrap(True)
                v.addWidget(h)
            if f.kind == "bool":
                self._lay.addRow(box)
            else:
                label = QLabel(f.label + (" *" if f.required else ""))
                self._lay.addRow(label, box)

    def values(self) -> dict:
        return {k: g() for k, g in self._getters.items()}

    def _make(self, f: Field):
        k = f.kind
        if k == "bool":
            w = QCheckBox(f.label)
            w.setChecked(bool(f.default))
            return w, w.isChecked
        if k == "choice":
            w = QComboBox()
            w.addItems([str(c) for c in f.choices])
            i = w.findText(str(f.default))
            if i >= 0:
                w.setCurrentIndex(i)
            return w, w.currentText
        if k == "int":
            w = QSpinBox()
            w.setRange(int(f.minimum), int(f.maximum))
            w.setValue(int(f.default or 0))
            return w, w.value
        if k == "float":
            w = QDoubleSpinBox()
            w.setRange(float(f.minimum), float(f.maximum))
            w.setDecimals(1)
            w.setValue(float(f.default or 0))
            return w, w.value
        if k == "multiline":
            w = QPlainTextEdit()
            w.setPlainText(str(f.default))
            w.setFixedHeight(90)
            return w, w.toPlainText
        if k == "file":
            box = QWidget()
            h = QHBoxLayout(box)
            h.setContentsMargins(0, 0, 0, 0)
            edit = QLineEdit(str(f.default))
            edit.setPlaceholderText("No file chosen")
            btn = QPushButton("Browse…")

            def pick():
                p, _ = QFileDialog.getOpenFileName(self, f.label, "", f.filt or "All files (*)")
                if p:
                    edit.setText(p)
            btn.clicked.connect(pick)
            h.addWidget(edit, 1)
            h.addWidget(btn)
            return box, edit.text
        w = QLineEdit(str(f.default))
        if k == "password":
            w.setEchoMode(QLineEdit.EchoMode.Password)
        return w, w.text
