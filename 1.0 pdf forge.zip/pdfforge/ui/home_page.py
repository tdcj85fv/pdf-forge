"""Home screen: every tool as a card, grouped by category, or a flat list of search results."""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import QFrame, QGridLayout, QLabel, QScrollArea, QVBoxLayout, QWidget

import app_config as C
from core import by_category
from .widgets import ToolCard

CARD_MIN_WIDTH = 270


class HomePage(QScrollArea):
    toolRequested = Signal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.host = QWidget()
        self.vbox = QVBoxLayout(self.host)
        self.vbox.setContentsMargins(28, 22, 28, 28)
        self.vbox.setSpacing(18)
        self.setWidget(self.host)
        self._sections: list[tuple[str, list]] = []
        self._empty = ""
        self._cols = 0
        self.show_all()

    # -- content
    def show_all(self):
        self._sections = [(name, tools) for _, name, tools in by_category()]
        self._empty = ""
        self._rebuild()

    def show_results(self, query: str, tools: list):
        if tools:
            self._sections = [(f"Results for “{query}”  ·  {len(tools)}", tools)]
            self._empty = ""
        else:
            self._sections = []
            self._empty = f"No tools match “{query}”. Try words like merge, compress, word, password or sign."
        self._rebuild()

    def first_result(self):
        for _, tools in self._sections:
            if tools:
                return tools[0]
        return None

    # -- layout
    def _columns(self) -> int:
        width = self.viewport().width() - 56
        return max(1, int(width // CARD_MIN_WIDTH))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        cols = self._columns()
        if cols != self._cols:
            self._rebuild()

    def _rebuild(self):
        self._cols = self._columns()
        while self.vbox.count():
            item = self.vbox.takeAt(0)
            w = item.widget()
            if w:
                w.setParent(None)
                w.deleteLater()
        if self._empty:
            lbl = QLabel(self._empty)
            lbl.setObjectName("muted")
            lbl.setWordWrap(True)
            lbl.setContentsMargins(0, 40, 0, 0)
            lbl.setAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
            self.vbox.addWidget(lbl)
        for title, tools in self._sections:
            sec = QWidget()
            sl = QVBoxLayout(sec)
            sl.setContentsMargins(0, 0, 0, 0)
            sl.setSpacing(10)
            h = QLabel(title.upper())
            h.setObjectName("h2")
            sl.addWidget(h)
            grid_host = QWidget()
            grid = QGridLayout(grid_host)
            grid.setContentsMargins(0, 0, 0, 0)
            grid.setSpacing(12)
            for i, t in enumerate(tools):
                card = ToolCard(t)
                card.clicked.connect(lambda _=False, tid=t.id: self.toolRequested.emit(tid))
                grid.addWidget(card, i // self._cols, i % self._cols)
            for c in range(self._cols):
                grid.setColumnStretch(c, 1)
            sl.addWidget(grid_host)
            self.vbox.addWidget(sec)
        self.vbox.addStretch(1)
